<?php

namespace App\Http\Controllers\my_class\Curriculums;

use App\Http\Controllers\Controller;
use App\Models\my_class\Curriculums\CurriculumLesson;
use Illuminate\Http\Request;

class CurriculumLessonController extends Controller
{
    public function index()
    {
        $lessons = CurriculumLesson::with(['school', 'curriculum'])->paginate(10);
        return response()->json($lessons);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'school_id' => 'required|exists:schools,id',
            'curriculum_id' => 'required|exists:curricula,id',
            'selected' => 'boolean',
            'topic_number' => 'required|string',
            'topic_title' => 'required|string',
            'lesson_number' => 'required|string',
            'lesson_title' => 'required|string',
            'page_number' => 'nullable|integer',
            'description' => 'nullable|string',
            'standard' => 'nullable|string',
            'strand' => 'nullable|string',
            'content' => 'nullable|string',
            'skill' => 'nullable|string',
            'activities' => 'nullable|json',
            'assignment' => 'nullable|string',
            'assessment' => 'nullable|string',
            'notes_admin' => 'nullable|string',
            'notes_teacher' => 'nullable|string',
            'data' => 'nullable|json',
            'options' => ['required', 'json', function ($attribute, $value, $fail) {
                $options = json_decode($value, true);
                if (!is_array($options)) {
                    $fail('The options must be a valid JSON array.');
                    return;
                }

                foreach ($options as $option) {
                    if (!isset($option['option']) || !isset($option['isCorrect']) || !isset($option['feedback'])) {
                        $fail('Each option must contain option text, isCorrect flag, and feedback.');
                        return;
                    }
                }
            }],
        ]);

        $lesson = CurriculumLesson::create($validated);

        return response()->json([
            'message' => 'Curriculum lesson created successfully',
            'record' => $lesson->load(['school', 'curriculum'])
        ], 201);
    }

    public function show(CurriculumLesson $curriculumLesson)
    {
        return response()->json($curriculumLesson->load(['school', 'curriculum']));
    }

    public function update(Request $request, CurriculumLesson $curriculumLesson)
    {
        $validated = $request->validate([
            'school_id' => 'sometimes|required|exists:schools,id',
            'curriculum_id' => 'sometimes|required|exists:curricula,id',
            'selected' => 'sometimes|boolean',
            'topic_number' => 'sometimes|required|string',
            'topic_title' => 'sometimes|required|string',
            'lesson_number' => 'sometimes|required|string',
            'lesson_title' => 'sometimes|required|string',
            'page_number' => 'nullable|integer',
            'description' => 'nullable|string',
            'standard' => 'nullable|string',
            'strand' => 'nullable|string',
            'content' => 'nullable|string',
            'skill' => 'nullable|string',
            'activities' => 'nullable|json',
            'assignment' => 'nullable|string',
            'assessment' => 'nullable|string',
            'notes_admin' => 'nullable|string',
            'notes_teacher' => 'nullable|string',
            'data' => 'nullable|json',
            'options' => ['required', 'json', function ($attribute, $value, $fail) {
                $options = json_decode($value, true);
                if (!is_array($options)) {
                    $fail('The options must be a valid JSON array.');
                    return;
                }

                foreach ($options as $option) {
                    if (!isset($option['option']) || !isset($option['isCorrect']) || !isset($option['feedback'])) {
                        $fail('Each option must contain option text, isCorrect flag, and feedback.');
                        return;
                    }
                }
            }],
        ]);

        $curriculumLesson->update($validated);

        return response()->json([
            'message' => 'Curriculum lesson updated successfully',
            'record' => $curriculumLesson->load(['school', 'curriculum'])
        ]);
    }

    public function destroy(CurriculumLesson $curriculumLesson)
    {
        $curriculumLesson->delete();
        return response()->json(['message' => 'Curriculum lesson deleted successfully']);
    }
}
