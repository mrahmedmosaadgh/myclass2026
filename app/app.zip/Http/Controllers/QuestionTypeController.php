<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;

class QuestionTypeController extends Controller
{
    public function index()
    {
        $questionTypes = [
            ['id' => 'mcq', 'name' => 'Multiple Choice'],
            ['id' => 'true_false', 'name' => 'True/False'],
            ['id' => 'fill_blank', 'name' => 'Fill in the Blank'],
            ['id' => 'short_answer', 'name' => 'Short Answer'],
            ['id' => 'essay', 'name' => 'Essay'],
            ['id' => 'matching', 'name' => 'Matching'],
        ];

        return Inertia::render('my_class/teacher/QuestionTypes/Index', [
            'questionTypes' => $questionTypes
        ]);
    }
}