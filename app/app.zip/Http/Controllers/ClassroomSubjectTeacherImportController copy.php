<?php

namespace App\Http\Controllers;

use App\Models\Classroom;
use App\Models\Subject;
use App\Models\Teacher;
use App\Models\ClassroomSubjectTeacher;
use Illuminate\Http\Request;

class ClassroomSubjectTeacherImportController extends Controller
{
    public function create()
    {
        return view('classroom-subject-teacher.import');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'data' => 'required|array',
            'data.*.classroom' => 'required|string',
            'data.*.subject' => 'required|string',
            'data.*.teacher' => 'required|string',
            'data.*.classes_per_week' => 'required|integer|min:1',
        ]);

        foreach ($validated['data'] as $row) {
            $classroom = Classroom::where('name', $row['classroom'])->first();
            $subject = Subject::where('name', $row['subject'])->first();
            $teacher = Teacher::where('name', $row['teacher'])->first();
            
            if ($classroom && $subject && $teacher) {
                ClassroomSubjectTeacher::updateOrCreate(
                    [
                        'classroom_id' => $classroom->id,
                        'subject_id' => $subject->id,
                        'teacher_id' => $teacher->id
                    ],
                    ['classes_per_week' => $row['classes_per_week']]
                );
            }
        }
        
        return back()->with('success', 'Data imported successfully');
    }
}
