<?php

namespace App\Models\my_class\Curriculums;

use App\Models\Curriculum;
use Illuminate\Database\Eloquent\Model;
use App\Models\School;

class CurriculumLesson extends Model
{
    protected $fillable = [
        'school_id',
        'curriculum_id',
        'selected',
        'topic_number',
        'topic_title',
        'lesson_number',
        'lesson_title',
        'page_number',
        'description',
        'standard',
        'strand',
        'content',
        'skill',
        'activities',
        'assignment',
        'assessment',
        'notes_admin',
        'notes_teacher',
        'data'
    ];

    protected $casts = [
        'selected' => 'integer',
        'page_number' => 'integer',
        'data' => 'json',
        'activities' => 'array'
    ];

    public function school()
    {
        return $this->belongsTo(School::class);
    }

    public function curriculum()
    {
        return $this->belongsTo(Curriculum::class);
    }
}
