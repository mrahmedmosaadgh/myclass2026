<?php

namespace App\Models;

use App\Models\my_class\Curriculums\CurriculumLesson;
use Illuminate\Database\Eloquent\Model;

class QuestionBank extends Model
{
    protected $fillable = [
        'school_id',
        'subject_id',
        'curriculum_id',
        'title',
        'body',
        'type',
        'score',
        'difficulty',
        'options',
        'explanation',
        'notes',
        'created_by_id'
    ];

    protected $casts = [
        'options' => 'array',
        'resources' => 'array',
        'explanation' => 'array',
        'question_data' => 'array'
    ];

    public function school()
    {
        return $this->belongsTo(School::class);
    }

    public function subject()
    {
        return $this->belongsTo(Subject::class);
    }

    public function curriculum()
    {
        return $this->belongsTo(Curriculum::class);
    }

    public function curriculumLesson()
    {
        return $this->belongsTo(CurriculumLesson::class, 'curriculum_lessons_id');
    }

    public function createdBy()
    {
        return $this->belongsTo(Teacher::class, 'created_by_id');
    }
}



