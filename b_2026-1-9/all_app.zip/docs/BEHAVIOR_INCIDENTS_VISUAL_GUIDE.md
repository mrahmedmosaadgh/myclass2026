# Behavior Incidents - Visual Guide

## 🎨 User Interface Overview

### Main Screen Layout
```
┌─────────────────────────────────────────────────────────────┐
│  Behavior Incidents          [Print Report] [EN/AR Toggle]  │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Select Students                [Select All] [Clear]         │
│  [Record Incident (3)]                                       │
│                                                               │
│  ┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐                   │
│  │ ✓  │  │ ✓  │  │    │  │ ✓  │  │    │  ...              │
│  │👤 │  │👤 │  │👤 │  │👤 │  │👤 │                       │
│  │Ali │  │Sara│  │Omar│  │Mona│  │Zaid│                    │
│  └────┘  └────┘  └────┘  └────┘  └────┘                   │
│                                                               │
│  Selected Students (3):                                      │
│  [Ali ×] [Sara ×] [Mona ×]                                  │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  Recent Incidents                                            │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ [Minor] 2025-02-10 09:15                            │   │
│  │ Student A - Grade 5                                  │   │
│  │ Classroom | Disruption                              │   │
│  │ "Student repeatedly talked..."          [👁] [🗑]   │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### Incident Recording Dialog
```
┌─────────────────────────────────────────────────────────────┐
│  Record Behavior Incident - 3 Student(s)              [×]   │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  Selected Students: [Ali] [Sara] [Mona]                     │
│                                                               │
│  ┌──────────────────────┐  ┌──────────────────────┐        │
│  │ 📅 When & Where      │  │ 📝 Description       │        │
│  ├──────────────────────┤  ├──────────────────────┤        │
│  │ Date: [2025-02-10]   │  │ Description (EN):    │        │
│  │ Time: [09:15]        │  │ ┌──────────────────┐ │        │
│  │ Location: [Classroom]│  │ │ Student talked... │ │        │
│  └──────────────────────┘  │ │                   │ │        │
│                             │ └──────────────────┘ │        │
│  ┌──────────────────────┐  │ Description (AR):    │        │
│  │ ⚠️ Incident Details  │  │ ┌──────────────────┐ │        │
│  ├──────────────────────┤  │ │ تحدث الطالب...   │ │        │
│  │ Type: [Minor ▼]      │  │ └──────────────────┘ │        │
│  │ Behavior: [Disrupt ▼]│  └──────────────────────┘        │
│  │ Motivation: [Peer ▼] │                                   │
│  │ Others: [None ▼]     │  ┌──────────────────────┐        │
│  └──────────────────────┘  │ ✅ Actions Taken     │        │
│                             ├──────────────────────┤        │
│  ┌──────────────────────┐  │ Teacher Action (EN): │        │
│  │ ⚡ Quick Actions     │  │ [Verbal reminder]    │        │
│  ├──────────────────────┤  │ Teacher Action (AR): │        │
│  │ [Load Last Settings] │  │ [تنبيه شفهي]        │        │
│  │ [Save as Template]   │  │ Admin Action:        │        │
│  └──────────────────────┘  │ [Optional...]        │        │
│                             │ ☑ Follow-up Needed   │        │
│                             └──────────────────────┘        │
│                                                               │
│                          [Cancel] [Record Incident]          │
└─────────────────────────────────────────────────────────────┘
```

### Student History Dialog
```
┌─────────────────────────────────────────────────────────────┐
│  Student Behavior History                             [×]   │
│  Ali Ahmed - Last 90 Days                                   │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐                   │
│  │  15  │  │  10  │  │   5  │  │  -15 │                   │
│  │Total │  │Minor │  │Major │  │Points│                    │
│  └──────┘  └──────┘  └──────┘  └──────┘                   │
│                                                               │
│  Recent Incidents:                                           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ [Minor] 2025-02-10 | Disruption                     │   │
│  │ "Student talked during lesson..."                   │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ [Major] 2025-02-08 | Physical Aggression            │   │
│  │ "Pushed another student..."                         │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ [Minor] 2025-02-05 | Noncompliance                  │   │
│  │ "Refused to line up..."                             │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                               │
│                                          [Close]             │
└─────────────────────────────────────────────────────────────┘
```

### Print Report Layout
```
┌─────────────────────────────────────────────────────────────┐
│                                                               │
│              BEHAVIOR INCIDENT REPORT                        │
│              ═══════════════════════════                     │
│                                                               │
│              Date: February 10, 2025                         │
│              Classroom ID: 10                                │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  SUMMARY                                                     │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐                   │
│  │  10  │  │   7  │  │   3  │  │  10  │                   │
│  │Total │  │Minor │  │Major │  │Points│                    │
│  └──────┘  └──────┘  └──────┘  └──────┘                   │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  INCIDENTS BY STUDENT                                        │
│  ┌─────────────┬───────┬───────┬───────┬────────┐          │
│  │ Student     │ Total │ Minor │ Major │ Points │          │
│  ├─────────────┼───────┼───────┼───────┼────────┤          │
│  │ Ali Ahmed   │   3   │   2   │   1   │   -3   │          │
│  │ Sara Omar   │   2   │   2   │   0   │   -2   │          │
│  │ Mona Zaid   │   2   │   1   │   1   │   -2   │          │
│  └─────────────┴───────┴───────┴───────┴────────┘          │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  DETAILED INCIDENTS                                          │
│                                                               │
│  1. Ali Ahmed [Minor] 2025-02-10 09:15                      │
│     Location: Classroom | Behavior: Disruption              │
│     Description: Student repeatedly talked during           │
│     independent work.                                        │
│     Teacher Action: Verbal reminder                         │
│                                                               │
│  2. Sara Omar [Minor] 2025-02-10 09:15                      │
│     Location: Classroom | Behavior: Disruption              │
│     Description: Student repeatedly talked during           │
│     independent work.                                        │
│     Teacher Action: Verbal reminder                         │
│                                                               │
│  [... more incidents ...]                                    │
│                                                               │
├─────────────────────────────────────────────────────────────┤
│  Generated on: 2025-02-10 14:30:00                          │
└─────────────────────────────────────────────────────────────┘
```

## 🎨 Color Coding

### Form Groups
```
📅 When & Where       → Blue (#EFF6FF)
⚠️ Incident Details   → Orange (#FFF7ED)
📝 Description        → Green (#F0FDF4)
✅ Actions Taken      → Purple (#FAF5FF)
⚡ Quick Actions      → Gray (#F9FAFB)
```

### Severity Indicators
```
Minor Incidents    → Yellow/Orange border (#FEF3C7)
Major Incidents    → Red border (#FEE2E2)
```

### Status Badges
```
Minor    → [Orange Badge]
Major    → [Red Badge]
Open     → [Blue Badge]
Resolved → [Green Badge]
```

## 🖱️ Interactive Elements

### Student Cards
```
┌────────────┐
│  Selected  │  ← Blue border when selected
│    ✓       │  ← Checkmark appears
│   👤       │  ← Avatar
│   Ali      │  ← Name
│  Ahmed     │
│            │
│  +5  -2   │  ← Points summary
└────────────┘
    ↑
  Clickable
```

### Selection Chips
```
[Ali Ahmed ×]  ← Click × to remove
  ↑
Blue chip with white text
Removable
```

### Action Buttons
```
[Record Incident (3)]  ← Shows selected count
     ↑
  Disabled if count = 0
  Primary color when enabled
```

## 📱 Responsive Behavior

### Desktop (>1024px)
```
┌─────────────────────────────────────┐
│  [Student Cards in Grid - 5 per row]│
│  [Form in 2 columns]                │
└─────────────────────────────────────┘
```

### Tablet (768px - 1024px)
```
┌──────────────────────────┐
│  [Cards - 3 per row]     │
│  [Form in 2 columns]     │
└──────────────────────────┘
```

### Mobile (<768px)
```
┌────────────────┐
│  [Cards - 2/row]│
│  [Form - 1 col] │
└────────────────┘
```

## 🎯 User Flow Diagram

```
START
  │
  ├─→ View Incidents List
  │     │
  │     ├─→ View Details → View History
  │     └─→ Delete Incident
  │
  ├─→ Select Students (Cards)
  │     │
  │     ├─→ Click individual cards
  │     ├─→ Use "Select All"
  │     └─→ Remove with chips
  │
  ├─→ Record Incident
  │     │
  │     ├─→ Fill grouped form
  │     ├─→ Load last settings
  │     ├─→ Save as template
  │     └─→ Submit (batch save)
  │
  └─→ Print Report
        │
        ├─→ Review formatted report
        └─→ Print or Export PDF
```

## 💡 Visual Tips

### Selection Feedback
- **Unselected Card**: White background, gray border
- **Selected Card**: Blue border, checkmark icon
- **Hover**: Slight shadow, cursor pointer

### Form Validation
- **Required Fields**: Red asterisk (*)
- **Invalid Input**: Red border
- **Valid Input**: Green checkmark

### Loading States
- **Loading Data**: Spinner with message
- **Saving**: Button shows loading spinner
- **Success**: Green notification toast

### Empty States
- **No Incidents**: Icon + friendly message
- **No Selection**: Disabled button + tooltip

---

**This visual guide helps understand the UI layout and user interactions!**
