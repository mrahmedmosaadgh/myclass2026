# 👁️ Visual Guide: Attendance & Points Rules

## 🎬 Scenario 1: Marking Student Absent (With Points)

### Before
```
┌─────────────────────────────────────────────────┐
│ 📋 Attendance Tab                               │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌──────────────┐  ┌──────────────┐            │
│  │ 👤 Ahmed     │  │ 👤 Sara      │            │
│  │ ✅ Present   │  │ ✅ Present   │            │
│  │ +15 ⭐       │  │ +20 ⭐       │            │
│  │ -5 ⚠️        │  │ -0 ⚠️        │            │
│  └──────────────┘  └──────────────┘            │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Teacher Clicks Ahmed
```
┌─────────────────────────────────────────────────┐
│ ⚠️  Warning                                     │
├─────────────────────────────────────────────────┤
│                                                 │
│  This student has 15 positive and 5 negative   │
│  points for this session. Marking them absent  │
│  will remove all their points for this         │
│  session. Continue?                            │
│                                                 │
│  ┌─────────────┐  ┌──────────────────────┐    │
│  │   Cancel    │  │  Yes, Mark Absent    │    │
│  └─────────────┘  └──────────────────────┘    │
│                                                 │
└─────────────────────────────────────────────────┘
```

### After Confirming
```
┌─────────────────────────────────────────────────┐
│ 📋 Attendance Tab                               │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌──────────────┐  ┌──────────────┐            │
│  │ 👤 Ahmed     │  │ 👤 Sara      │            │
│  │ ❌ Absent    │  │ ✅ Present   │            │
│  │ +0 ⭐        │  │ +20 ⭐       │            │
│  │ -0 ⚠️        │  │ -0 ⚠️        │            │
│  │ (grayed out) │  │              │            │
│  └──────────────┘  └──────────────┘            │
│                                                 │
│  ✅ Student marked absent and points removed   │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 🎬 Scenario 2: Trying to Add Points to Absent Student

### + Points Tab View
```
┌─────────────────────────────────────────────────┐
│ 📋 + Points Tab                                 │
├─────────────────────────────────────────────────┤
│                                                 │
│  Select behavior: [Great participation (+5)]   │
│  [Apply to Selected]                           │
│                                                 │
│  ┌──────────────┐  ┌──────────────┐            │
│  │ 👤 Ahmed     │  │ 👤 Sara      │            │
│  │ ❌ Absent    │  │ ✅ Present   │            │
│  │ ☐ Disabled   │  │ ☑️ Enabled   │            │
│  │ +0 ⭐        │  │ +20 ⭐       │            │
│  │ (grayed out) │  │ (clickable)  │            │
│  └──────────────┘  └──────────────┘            │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Teacher Tries to Click Ahmed
```
┌─────────────────────────────────────────────────┐
│ 📋 + Points Tab                                 │
├─────────────────────────────────────────────────┤
│                                                 │
│  ⚠️ Cannot select absent students              │
│                                                 │
│  ┌──────────────┐  ┌──────────────┐            │
│  │ 👤 Ahmed     │  │ 👤 Sara      │            │
│  │ ❌ Absent    │  │ ✅ Present   │            │
│  │ ☐ Disabled   │  │ ☑️ Enabled   │            │
│  │ (no change)  │  │              │            │
│  └──────────────┘  └──────────────┘            │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 🎬 Scenario 3: History Shows Canceled Points

### History Tab After Marking Absent
```
┌─────────────────────────────────────────────────┐
│ 📋 History Tab                                  │
├─────────────────────────────────────────────────┤
│                                                 │
│  ┌───────────────────────────────────────────┐ │
│  │ 👤 Ahmed ⭐                                │ │
│  │ Great participation (+5 points)           │ │
│  │ Nov 17, 2:30 PM by Mr. Smith              │ │
│  │ ❌ Canceled: Student marked absent        │ │
│  │ (grayed out, no undo button)              │ │
│  └───────────────────────────────────────────┘ │
│                                                 │
│  ┌───────────────────────────────────────────┐ │
│  │ 👤 Ahmed ⭐                                │ │
│  │ Homework completed (+10 points)           │ │
│  │ Nov 17, 2:25 PM by Mr. Smith              │ │
│  │ ❌ Canceled: Student marked absent        │ │
│  │ (grayed out, no undo button)              │ │
│  └───────────────────────────────────────────┘ │
│                                                 │
│  ┌───────────────────────────────────────────┐ │
│  │ 👤 Sara ⭐                                 │ │
│  │ Great participation (+5 points)           │ │
│  │ Nov 17, 2:20 PM by Mr. Smith   [Undo]    │ │
│  │ (active, can be undone)                   │ │
│  └───────────────────────────────────────────┘ │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 🎬 Scenario 4: Batch Mark All Absent

### Before
```
┌─────────────────────────────────────────────────┐
│ 📋 Attendance Tab                               │
├─────────────────────────────────────────────────┤
│                                                 │
│  [Mark All Present]  [Mark All Absent]         │
│                                                 │
│  25 students present                           │
│  Total points in session: 150+, 30-            │
│                                                 │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐          │
│  │Ahmed │ │Sara  │ │Omar  │ │Fatima│          │
│  │✅ +15│ │✅ +20│ │✅ +10│ │✅ +5 │          │
│  └──────┘ └──────┘ └──────┘ └──────┘          │
│  ... (21 more students)                        │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Teacher Clicks "Mark All Absent"
```
┌─────────────────────────────────────────────────┐
│ 📋 Attendance Tab                               │
├─────────────────────────────────────────────────┤
│                                                 │
│  [Mark All Present]  [Mark All Absent]         │
│                                                 │
│  ⏳ Processing...                              │
│                                                 │
└─────────────────────────────────────────────────┘
```

### After
```
┌─────────────────────────────────────────────────┐
│ 📋 Attendance Tab                               │
├─────────────────────────────────────────────────┤
│                                                 │
│  [Mark All Present]  [Mark All Absent]         │
│                                                 │
│  ✅ Updated 25 students, removed 47 point      │
│     actions                                    │
│                                                 │
│  25 students absent                            │
│  All points removed                            │
│                                                 │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐          │
│  │Ahmed │ │Sara  │ │Omar  │ │Fatima│          │
│  │❌ +0 │ │❌ +0 │ │❌ +0 │ │❌ +0 │          │
│  │(gray)│ │(gray)│ │(gray)│ │(gray)│          │
│  └──────┘ └──────┘ └──────┘ └──────┘          │
│  ... (21 more students, all grayed)           │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 🎬 Scenario 5: Tab Switching Clears Selection

### In + Points Tab
```
┌─────────────────────────────────────────────────┐
│ [Attendance] [+ Points✓] [- Points] [History]  │
├─────────────────────────────────────────────────┤
│                                                 │
│  Selected: 3 students                          │
│                                                 │
│  ┌──────────────┐  ┌──────────────┐            │
│  │ 👤 Sara      │  │ 👤 Omar      │            │
│  │ ☑️ Selected  │  │ ☑️ Selected  │            │
│  │ +20 ⭐       │  │ +10 ⭐       │            │
│  └──────────────┘  └──────────────┘            │
│                                                 │
│  ┌──────────────┐                               │
│  │ 👤 Fatima    │                               │
│  │ ☑️ Selected  │                               │
│  │ +5 ⭐        │                               │
│  └──────────────┘                               │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Switch to - Points Tab
```
┌─────────────────────────────────────────────────┐
│ [Attendance] [+ Points] [- Points✓] [History]  │
├─────────────────────────────────────────────────┤
│                                                 │
│  Selected: 0 students                          │
│  (selection cleared automatically)             │
│                                                 │
│  ┌──────────────┐  ┌──────────────┐            │
│  │ 👤 Sara      │  │ 👤 Omar      │            │
│  │ ☐ Not sel.   │  │ ☐ Not sel.   │            │
│  │ -0 ⚠️        │  │ -3 ⚠️        │            │
│  └──────────────┘  └──────────────┘            │
│                                                 │
│  ┌──────────────┐                               │
│  │ 👤 Fatima    │                               │
│  │ ☐ Not sel.   │                               │
│  │ -0 ⚠️        │                               │
│  └──────────────┘                               │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 🎨 Color Legend

| Visual | Meaning |
|--------|---------|
| 🟢 Green border | Present student (selectable) |
| 🔴 Red border | Selected for negative points |
| 🔵 Blue border | Selected for positive points |
| ⚪ Gray background | Absent student (disabled) |
| ✅ Green checkmark | Present |
| ❌ Red X | Absent |
| ⭐ Star | Positive points |
| ⚠️ Warning | Negative points |
| ☑️ Checked box | Selected |
| ☐ Empty box | Not selected |
| ⏳ Hourglass | Loading/Processing |

---

## 📱 Mobile View

### Attendance Tab (Mobile)
```
┌─────────────────────┐
│ 🏆 Reward System    │
├─────────────────────┤
│ [Attendance✓]      │
│ [+ Points]         │
│ [- Points]         │
│ [History]          │
├─────────────────────┤
│                     │
│ ┌─────────────────┐ │
│ │ 👤 Ahmed        │ │
│ │ ❌ Absent       │ │
│ │ +0 ⭐ -0 ⚠️     │ │
│ │ [Toggle]        │ │
│ └─────────────────┘ │
│                     │
│ ┌─────────────────┐ │
│ │ 👤 Sara         │ │
│ │ ✅ Present      │ │
│ │ +20 ⭐ -0 ⚠️    │ │
│ │ [Toggle]        │ │
│ └─────────────────┘ │
│                     │
│ (scroll for more)   │
│                     │
└─────────────────────┘
```

---

## 🎯 Quick Reference

### Student States

**Present (Normal)**
- Green border
- Checkbox enabled
- Can receive points
- Clickable in all tabs

**Absent (Restricted)**
- Gray background
- Checkbox disabled
- Cannot receive points
- Shows "❌ Absent" label

**Selected (Active)**
- Colored border (green/red)
- Checkbox checked
- Ready for bulk action
- Cleared when switching tabs

---

**Last Updated:** 2025-11-17
**Version:** 2.1
