<template>
    <div>
        <LessonExplain />
    </div>
</template>

<script setup>
import LessonExplain from './lesson_explain.vue';
</script>
