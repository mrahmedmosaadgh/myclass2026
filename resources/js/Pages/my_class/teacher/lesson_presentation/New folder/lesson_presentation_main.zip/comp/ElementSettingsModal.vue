<template>
  <div v-if="modelValue && element" class="modal-backdrop" @click="$emit('update:modelValue', false)">
    <div class="settings-modal" @click.stop>
      <h3>Element Settings</h3>
      <p>
        <label>
          Text Color:
          <input
            type="color"
            :value="element.style.color"
            @change="updateStyle('color', $event.target.value)"
          >
        </label>
      </p>
      <p>
        <label>
          Background Color:
          <input
            type="color"
            :value="element.style.backgroundColor"
            @change="updateStyle('backgroundColor', $event.target.value)"
          >
        </label>
      </p>
      <p>
        <label>
          Font Size:
          <input
            type="number"
            :value="parseInt(element.style.fontSize)"
            min="8"
            max="72"
            step="1"
            style="width: 60px"
            @change="updateStyle('fontSize', $event.target.value + 'px')"
          >
          px
        </label>
      </p>
      <button @click="$emit('update:modelValue', false)">Close</button>
    </div>
  </div>
</template>

<script setup>
defineProps({
  modelValue: Boolean,
  element: {
    type: Object,
    required: true,
    default: () => ({
      style: {
        color: '#000000',
        backgroundColor: '#ffffff',
        fontSize: '16px'
      }
    })
  }
});

const emit = defineEmits(['update:modelValue', 'updateStyle']);

const updateStyle = (property, value) => {
  emit('updateStyle', { property, value });
};
</script>
