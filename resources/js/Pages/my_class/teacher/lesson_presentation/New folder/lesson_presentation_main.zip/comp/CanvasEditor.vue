<template>
    <div class="canvas-container" :class="{ 'presentation-mode': presentationMode }">
      <!-- Add controls panel -->
      <div class="controls-panel" v-if="!readonly">
        <input type="file" id="bgInput" accept="image/*" style="display: none" @change="handleBackgroundImage">
        <button @click="$refs.bgInput.click()">Choose Background</button>
        <button @click="toggleAllElements">Show/Hide All</button>
        <button @click="addNewElement(20, 20)">Add Element</button>
        <select v-model="zoomLevel" @change="handleZoomChange">
          <option value="fit">Fit Width</option>
          <option value="0.5">50%</option>
          <option value="1">100%</option>
          <option value="1.2">120%</option>
          <option value="1.5">150%</option>
          <option value="2">200%</option>
          <option value="2.5">250%</option>
        </select>
        <button @click="saveToFile">Save to File</button>
        <button @click="loadFromFile">Load from File</button>
      </div>

      <div
        id="canvas"
        ref="canvasRef"
        class="canvas"
        :style="{
          backgroundImage: backgroundImage,
          backgroundSize: 'contain',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center',
          minHeight: `${canvasHeight}vh`,
          transform: `scale(${zoomLevel})`,
          transformOrigin: 'center center'
        }"
        @click="!readonly && handleCanvasClick"
      >
        <div
          v-for="(element, index) in elements"
          :key="element.id || index"
          class="element-container"
          :style="{
            left: `${element.x}%`,
            top: `${element.y}%`,
            pointerEvents: readonly ? 'none' : 'auto'
          }"
          :data-id="index"
          :data-locked="element.locked"
        >
          <div class="drag-handle" v-if="!readonly">
            <button
              class="control-button visibility"
              @click.stop="toggleElement(element.id)"
              :style="{
                display: 'block !important',
                opacity: element.visible ? '1' : '0.6'
              }"
            >
              {{ element.visible ? '👁' : '👁‍🗨' }}
            </button>
            <span
              class="drag-icon"
              :style="{ opacity: element.visible ? '1' : '0.1' }"
              @mousedown="!element.locked && element.visible && startDrag($event, element)"
            >↔</span>
          </div>

          <div class="controls" v-if="!readonly">
            <button
              class="control-button copy"
              @click="copyElement(element.id)"
              :style="{ opacity: element.visible ? '1' : '0.1' }"
            >📋</button>
            <button
              class="control-button lock"
              @click="toggleLock(element.id)"
              :style="{ opacity: element.visible ? '1' : '0.1' }"
            >{{ element.locked ? '🔒' : '🔓' }}</button>
            <button
              class="control-button settings"
              @click="openSettings(element)"
              :style="{ opacity: element.visible ? '1' : '0.1' }"
            >⚙️</button>
            <button
              class="control-button delete"
              @click="deleteElement(element.id)"
              :style="{ opacity: element.visible ? '1' : '0.1' }"
            >×</button>
          </div>

          <div
            class="element-content"
            :contenteditable="!readonly && !element.locked"
            :style="{
              ...element.style,
              opacity: element.visible ? '1' : '0.1'
            }"
            @blur="updateContent(element, $event)"
            v-html="element.content"
          ></div>
        </div>
      </div>

      <ElementSettingsModal
        v-if="showSettings && selectedElement && !readonly"
        v-model="showSettings"
        :element="selectedElement"
        @update-style="updateElementStyle"
      />
    </div>
  </template>

  <script setup>
  import { ref, onMounted, onUnmounted, watch } from 'vue';
  import ElementSettingsModal from './ElementSettingsModal.vue';
  import { toast } from 'vue3-toastify';

  // Add zoomLevel ref
  const zoomLevel = ref(1);

  const props = defineProps({
    modelValue: {
      type: Object,
      default: () => ({
        elements: [],
        backgroundImage: ''
      })
    },
    presentationMode: {
      type: Boolean,
      default: false
    },
    readonly: {
      type: Boolean,
      default: false
    }
  });

  const emit = defineEmits(['update:modelValue']);

  // Initialize refs
  const elements = ref([]);
  const isDragging = ref(false);
  const currentElement = ref(null);
  const offset = ref({ x: 0, y: 0 });
  const showSettings = ref(false);
  const selectedElement = ref(null);
  const canvasHeight = ref(100);
  const backgroundImage = ref('');
  const canvasRef = ref(null);

  // Safe initialization of elements
  const initializeElements = () => {
    try {
      elements.value = Array.isArray(props.modelValue?.elements)
        ? [...props.modelValue.elements]
        : [];
      backgroundImage.value = props.modelValue?.backgroundImage || '';
    } catch (error) {
      console.error('Error initializing elements:', error);
      elements.value = [];
      backgroundImage.value = '';
    }
  };

  // Save elements safely
  const saveElements = () => {
    try {
      emit('update:modelValue', {
        elements: elements.value,
        backgroundImage: backgroundImage.value
      });
    } catch (error) {
      console.error('Error saving elements:', error);
    }
  };

  const addNewElement = (x, y) => {
    const element = {
      id: Date.now(),
      type: 'text',
      content: 'New Element',
      x: Math.max(0, Math.min(90, x)),
      y: Math.max(0, y),
      visible: true,
      locked: false,
      style: {
        color: '#000000',
        backgroundColor: '#ffffff',
        fontSize: '16px'
      }
    };
    elements.value.push(element);
    saveElements();
  };

  const handleCanvasClick = (e) => {
    if (e.target === canvasRef.value) {
      const rect = canvasRef.value.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      addNewElement(x, y);
    }
  };

  const toggleElement = (id) => {
    const element = elements.value.find(el => el.id === id);
    if (element) {
      element.visible = !element.visible;
      saveElements();
    }
  };

  const copyElement = (id) => {
    const element = elements.value.find(el => el.id === id);
    if (element) {
      const newElement = {
        ...element,
        id: Date.now(),
        x: element.x + 5,
        y: element.y + 5
      };
      elements.value.push(newElement);
      saveElements();
    }
  };

  const deleteElement = (id) => {
    elements.value = elements.value.filter(el => el.id !== id);
    saveElements();
  };

  const toggleLock = (id) => {
    const element = elements.value.find(el => el.id === id);
    if (element) {
      element.locked = !element.locked;
      saveElements();
    }
  };

  const openSettings = (element) => {
    if (element) {
      selectedElement.value = element;
      showSettings.value = true;
    }
  };

  const updateElementStyle = ({ property, value }) => {
    if (selectedElement.value) {
      selectedElement.value.style[property] = value;
      saveElements();
    }
  };

  const updateContent = (element, event) => {
    element.content = event.target.innerHTML;
    saveElements();
  };

  const startDrag = (e, element) => {
    e.stopPropagation();
    isDragging.value = true;
    currentElement.value = element;
    const rect = e.target.getBoundingClientRect();
    offset.value = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const handleMouseMove = (e) => {
    if (!isDragging.value || !currentElement.value) return;

    const canvas = canvasRef.value;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - offset.value.x - rect.left) / rect.width) * 100;
    const y = ((e.clientY - offset.value.y - rect.top) / rect.height) * 100;

    currentElement.value.x = Math.max(0, Math.min(90, x));
    currentElement.value.y = Math.max(0, y);
  };

  const handleMouseUp = () => {
    if (isDragging.value) {
      isDragging.value = false;
      currentElement.value = null;
      saveElements();
    }
  };

  const toggleAllElements = () => {
    const allHidden = elements.value.every(el => !el.visible);
    elements.value.forEach(el => el.visible = allHidden);
    saveElements();
  };

  const handleZoomChange = () => {
    if (zoomLevel.value === 'fit') {
      // Implement fit width logic
    } else {
      const zoom = parseFloat(zoomLevel.value);
      // Implement zoom logic
    }
  };

  const handleBackgroundImage = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        backgroundImage.value = `url(${e.target.result})`;
        saveElements();
      };
      reader.readAsDataURL(file);
    }
  };

  const saveToFile = () => {
    try {
      // Validate slides exist
      if (!slides.value || slides.value.length === 0) {
        toast.error('No slides to save');
        return;
      }

      const fileName = prompt('Enter file name:', 'presentation_' + new Date().toISOString().slice(0,10));
      if (!fileName) return;

      const presentationData = {
        title: fileName,
        slides: slides.value.map(slide => ({
          elements: slide.content.elements || [],
          backgroundImage: slide.content.backgroundImage || '',
        })),
        version: "1.0",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const blob = new Blob([JSON.stringify(presentationData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${fileName}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast.success(`Successfully saved presentation with ${slides.value.length} slides`);
    } catch (error) {
      console.error('Error saving presentation:', error);
      toast.error('Error saving presentation: ' + error.message);
    }
  };

  const loadFromFile = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          elements.value = data.elements;
          backgroundImage.value = data.backgroundImage;
          saveElements();
        } catch (error) {
          console.error('Error loading file:', error);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  onMounted(() => {
    try {
      initializeElements();

      if (!props.readonly) {
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
      }
    } catch (error) {
      console.error('Error in onMounted:', error);
    }
  });

  onUnmounted(() => {
    try {
      if (!props.readonly) {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      }
    } catch (error) {
      console.error('Error in onUnmounted:', error);
    }
  });

  watch(() => props.modelValue, (newValue) => {
    try {
      if (newValue) {
        initializeElements();
      }
    } catch (error) {
      console.error('Error in modelValue watcher:', error);
    }
  }, { deep: true });

  // Add zoom methods
  const zoomIn = () => {
    zoomLevel.value = Math.min(zoomLevel.value + 0.1, 2);
  };

  const zoomOut = () => {
    zoomLevel.value = Math.max(zoomLevel.value - 0.1, 0.5);
  };

  const resetZoom = () => {
    zoomLevel.value = 1;
  };
  </script>

  <style scoped>
  .canvas-container {
    position: relative;
    width: 100%;
    height: 100%;
  }

  .canvas-container.presentation-mode {
    background: #000;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .canvas {
    position: relative;
    width: 100%;
    min-height: 100vh;
    background: white;
    transition: transform 0.2s ease-in-out;
  }

  .element-container {
    position: absolute;
    padding: 5px;
  }

  .drag-handle {
    cursor: move;
    padding: 2px;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .controls {
    display: flex;
    gap: 5px;
    margin-top: 5px;
  }

  .control-button {
    cursor: pointer;
    border: none;
    background: none;
    padding: 2px;
  }

  .element-content {
    min-width: 50px;
    min-height: 20px;
    padding: 5px;
    margin-top: 5px;
    border: 1px solid transparent;
  }

  .element-content:focus {
    border-color: #4a5568;
    outline: none;
  }

  .controls-panel {
    padding: 10px;
    background-color: #f5f5f5;
    border-bottom: 1px solid #ddd;
    display: flex;
    gap: 10px;
    align-items: center;
  }

  .controls-panel button {
    padding: 5px 10px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
  }

  .controls-panel button:hover {
    background-color: #f0f0f0;
  }

  .controls-panel select {
    padding: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .zoom-controls {
    position: absolute;
    bottom: 20px;
    right: 20px;
    display: flex;
    gap: 8px;
  }

  .zoom-controls button {
    padding: 4px 8px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
  }

  .zoom-controls button:hover {
    background: #f5f5f5;
  }
  </style>









