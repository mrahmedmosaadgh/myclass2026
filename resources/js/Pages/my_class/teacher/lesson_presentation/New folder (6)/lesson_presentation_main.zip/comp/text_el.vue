<template>
  <div class="text-element-container" :class="{ 'is-editing': isEditing }">
    <!-- Editable Content -->
    <div
      v-if="!readonly"
      ref="editableContent"
      contenteditable="true"
      :innerHTML="content"
      @input="handleContentInput"
      @blur="handleContentBlur"
      @focus="handleFocus"
      class="content-wrapper editable"
      :class="{
        'editing': isEditing,
        'hover-effect': !readonly,
        'empty': !content
      }"
    ></div>

    <!-- Read-only Content -->
    <div
      v-else
      :innerHTML="content"
      class="content-wrapper readonly"
    ></div>
  </div>
</template>

<script setup>
import { ref } from 'vue';

const props = defineProps({
  content: {
    type: String,
    default: ''
  },
  readonly: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['update:content']);
const isEditing = ref(false);
const editableContent = ref(null);

const handleContentInput = (event) => {
  // Remove any unnecessary whitespace/newlines while preserving formatting
  const content = event.target.innerHTML.trim();
  emit('update:content', content);
};

const handleContentBlur = (event) => {
  setTimeout(() => {
    isEditing.value = false;
  }, 200);
  handleContentInput(event);
};

const handleFocus = () => {
  isEditing.value = true;
};
</script>

<style scoped>
.text-element-container {
  display: inline-block;
  max-width: 100%;
}

.content-wrapper {
  @apply min-h-[2em] px-6 py-3 rounded-xl transition-all duration-300 ease-out;
  display: inline-block;
  width: auto;
  max-width: 100%;
  word-wrap: break-word;
  word-break: break-word;
  white-space: pre-wrap;
  background: rgba(255, 255, 255, 0.98);
  backdrop-filter: blur(10px);
  border: 2px solid transparent;
  box-shadow:
    0 4px 6px -1px rgba(0, 0, 0, 0.1),
    0 2px 4px -1px rgba(0, 0, 0, 0.06),
    inset 0 0 0 1px rgba(255, 255, 255, 0.1);
}

.content-wrapper.editable {
  @apply cursor-text;
  min-width: 30px;
}

.content-wrapper.empty:before {
  content: 'Click to add text...';
  @apply text-gray-400 italic;
}

.content-wrapper.editing {
  @apply ring-2 ring-indigo-500 ring-opacity-60;
  border-color: #6366f1;
  background: rgba(255, 255, 255, 0.999);
  box-shadow:
    0 12px 20px -4px rgba(99, 102, 241, 0.2),
    0 8px 12px -4px rgba(99, 102, 241, 0.15),
    inset 0 0 0 1px rgba(255, 255, 255, 0.3);
}

/* Dark mode adjustments */
@media (prefers-color-scheme: dark) {
  .content-wrapper {
    background: rgba(30, 41, 59, 0.95);
    color: #e2e8f0;
  }
}
</style>

