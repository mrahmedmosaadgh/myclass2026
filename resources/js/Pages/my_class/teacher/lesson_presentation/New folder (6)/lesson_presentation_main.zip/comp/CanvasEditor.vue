<template>
  <div class="canvas-editor">
    <div
      ref="canvasRef"
      class="canvas-area relative"
      :style="{
        transform: `scale(${zoomLevel})`,
        transformOrigin: 'top left',
        width: '100%',
        height: '100%',
        minWidth: '1200px'
      }"
    >
      <DraggableWrapper2
        v-for="element in elements"
        :key="element.id"
        v-model="element.position"
        :constraints="dragConstraints"
        :show-handle="!readonly"
        :hide-drag-handle="readonly || element.locked"
        drag-icon-name="move"
        @drag-start="handleDragStart(element)"
        @drag-end="handleDragEnd(element)"
        @update:modelValue="updateElementPosition(element, $event)"
      >
        <!-- Enhanced Control Icons -->
        <div
          class="element-controls"
          :class="{
            'opacity-0 group-hover:opacity-100': !element.locked,
            'opacity-100': element.locked
          }"
        >
          <div class="controls-container">
            <button
              class="control-button delete-button"
              @click.stop="deleteElement(element)"
              title="Delete element"
            >
              <LucideIcon
                name="x"
                size="16"
                class="text-red-600 hover:text-red-700"
              />
            </button>

            <button
              class="control-button"
              @click.stop="toggleVisibility(element)"
              :title="element.visible ? 'Hide element' : 'Show element'"
            >
              <LucideIcon
                :name="element.visible ? 'eye' : 'eye-off'"
                size="16"
                :class="element.visible ? 'text-blue-600' : 'text-gray-400'"
              />
            </button>

            <button
              class="control-button"
              @click.stop="toggleLock(element)"
              :title="element.locked ? 'Unlock element' : 'Lock element'"
            >
              <LucideIcon
                :name="element.locked ? 'lock' : 'unlock'"
                size="16"
                :class="element.locked ? 'text-orange-500' : 'text-gray-400'"
              />
            </button>
          </div>
        </div>

        <div class="element-wrapper border-4 border-red-600">
          <ElementContent
            :element="element"
            :readonly="readonly"
            :class="{
              'element-locked': element.locked,
              'element-hidden': !element.visible
            }"
            :style="{
              opacity: element.visible ? 1 : 0.5,
              cursor: element.locked ? 'default' : 'move',
              width: element.width ? `${element.width}px` : 'auto',
              height: element.height ? `${element.height}px` : 'auto',
              display: 'inline-block'
            }"
            @update:content="handleContentUpdate"
          />
        </div>
      </DraggableWrapper2>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import DraggableWrapper2 from './DraggableWrapper2.vue';
import ElementContent from './ElementContent.vue';
import LucideIcon from '@/Components/Common/LucideIcon.vue';

const props = defineProps({
  modelValue: {
    type: Object,
    default: () => ({
      elements: []
    })
  },
  readonly: {
    type: Boolean,
    default: false
  },
  zoomLevel: {
    type: Number,
    default: 1
  }
});

const emit = defineEmits(['update:modelValue', 'canvas-click', 'delete-element']);

// Transform elements to include position object while preserving all other properties
const elements = computed(() => {
  return props.modelValue.elements.map(element => ({
    ...element,
    position: {
      x: element.x,
      y: element.y
    }
  }));
});

const updateElementPosition = (element, newPosition) => {
  const updatedElements = props.modelValue.elements.map(el => {
    if (el.id === element.id) {
      return {
        ...el,  // Preserve all existing properties
        x: newPosition.x,
        y: newPosition.y
      };
    }
    return el;
  });

  emit('update:modelValue', {
    ...props.modelValue,
    elements: updatedElements
  });
};

const dragConstraints = {
  minX: 0,
  maxX: 1160, // Slightly less than CANVAS_DEFAULT_WIDTH to prevent overflow
  minY: 0,
  maxY: 800  // Adjust this value based on your needs
};

const handleDragStart = (element) => {
  if (props.readonly || element.locked) return;
  // Additional drag start logic if needed
};

const handleDragEnd = (element) => {
  if (props.readonly || element.locked) return;
  // Additional drag end logic if needed
};

const deleteElement = (element) => {
  if (props.readonly) return;
  const updatedElements = props.modelValue.elements.filter(el => el.id !== element.id);
  emit('update:modelValue', { ...props.modelValue, elements: updatedElements });
  emit('delete-element', element.id);
};

const toggleVisibility = (element) => {
  if (props.readonly) return;
  const updatedElements = props.modelValue.elements.map(el => {
    if (el.id === element.id) {
      return {
        ...el,  // Preserve all existing properties
        visible: !el.visible
      };
    }
    return el;
  });
  emit('update:modelValue', { ...props.modelValue, elements: updatedElements });
};

const toggleLock = (element) => {
  if (props.readonly) return;
  const updatedElements = props.modelValue.elements.map(el => {
    if (el.id === element.id) {
      return {
        ...el,  // Preserve all existing properties
        locked: !el.locked
      };
    }
    return el;
  });
  emit('update:modelValue', { ...props.modelValue, elements: updatedElements });
};

const handleContentUpdate = ({ element, content }) => {
  if (props.readonly) return;

  const updatedElements = props.modelValue.elements.map(el => {
    if (el.id === element.id) {
      return {
        ...el,
        content: content
      };
    }
    return el;
  });

  emit('update:modelValue', {
    ...props.modelValue,
    elements: updatedElements
  });
};
</script>

<style scoped>
.canvas-editor {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 600px;
  background: white;
  overflow: hidden;
}

.canvas-area {
  position: relative;
  width: 1200px;
  height: 100%;
  margin: 0 auto;
  transform-origin: top left;
}

.element-wrapper {
  position: relative;
  padding: 0;
  display: inline-block;
  overflow:visible;

}

.element-locked {
  pointer-events: none;
  filter: grayscale(0.2);
}

.element-hidden {
  opacity: 0.5;
}

.element-controls {
  position: absolute;
  top: -36px;
  right: -4px;
  z-index: 50;
  transition: all 0.2s ease-in-out;
}

.controls-container {
  display: flex;
  gap: 4px;
  padding: 4px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  border: 1px solid rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(8px);
}

.control-button {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: white;
  border: 1px solid #e2e8f0;
  cursor: pointer;
  transition: all 0.2s ease;
}

.control-button:hover {
  background: #f8fafc;
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.delete-button {
  border-color: #fee2e2;
}

.delete-button:hover {
  background: #fef2f2;
  border-color: #fecaca;
}

:deep(.element-content) {
  transform: none !important;
  width: 100%;
  height: 100%;
  min-width: 100px;
  display: inline-block;
}

:deep(.draggable-wrapper) {
  transform-origin: top left;
  position: absolute;
  display: inline-block;
}
</style>










