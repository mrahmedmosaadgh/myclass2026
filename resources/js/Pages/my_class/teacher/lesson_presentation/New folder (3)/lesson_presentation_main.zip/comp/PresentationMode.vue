<template>
  <div class="presentation-mode-container">
    <!-- Presentation Controls -->
    <div class="presentation-controls">
      <div class="slide-navigation">
        <button @click="previousSlide" :disabled="currentIndex === 0" class="nav-btn">
          <i class="fas fa-chevron-left"></i>
        </button>
        <span class="slide-counter">{{ currentIndex + 1 }} / {{ slides.length }}</span>
        <button @click="nextSlide" :disabled="currentIndex === slides.length - 1" class="nav-btn">
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <button @click="exitPresentation" class="exit-btn">
        <i class="fas fa-times mr-2"></i> Exit
      </button>
    </div>

    <!-- Slide Display -->
    <div class="presentation-view">
      <div class="slide-container">
        <CanvasEditor
          v-if="currentSlide"
          :key="currentIndex"
          v-model="currentSlide.content"
          :presentationMode="true"
          :readonly="true"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import CanvasEditor from './CanvasEditor.vue';

const props = defineProps({
  slides: {
    type: Array,
    required: true
  },
  initialIndex: {
    type: Number,
    default: 0
  }
});

const emit = defineEmits(['exit']);

const currentIndex = ref(props.initialIndex);

const currentSlide = computed(() => props.slides[currentIndex.value]);

const nextSlide = () => {
  if (currentIndex.value < props.slides.length - 1) {
    currentIndex.value++;
  }
};

const previousSlide = () => {
  if (currentIndex.value > 0) {
    currentIndex.value--;
  }
};

const exitPresentation = async () => {
  if (document.fullscreenElement) {
    await document.exitFullscreen();
  }
  emit('exit');
};

const handleKeyPress = (event) => {
  switch (event.key) {
    case 'ArrowRight':
    case 'Space':
      nextSlide();
      break;
    case 'ArrowLeft':
      previousSlide();
      break;
    case 'Escape':
      exitPresentation();
      break;
  }
};

onMounted(() => {
  document.addEventListener('keydown', handleKeyPress);
  document.documentElement.requestFullscreen().catch((e) => console.log(e));
});

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeyPress);
});
</script>

<style scoped>
.presentation-mode-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: #000;
  z-index: 1000;
}

.presentation-controls {
  position: fixed;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1000;
  display: flex;
  gap: 20px;
  align-items: center;
  background: rgba(0, 0, 0, 0.5);
  padding: 10px 20px;
  border-radius: 8px;
  opacity: 0.3;
  transition: opacity 0.3s;
}

.presentation-controls:hover {
  opacity: 1;
}

.slide-navigation {
  display: flex;
  align-items: center;
  gap: 10px;
}

.nav-btn {
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  padding: 5px 10px;
  font-size: 1.2em;
}

.nav-btn:disabled {
  opacity: 0.3;
  cursor: not-allowed;
}

.slide-counter {
  color: white;
  font-size: 0.9em;
  min-width: 60px;
  text-align: center;
}

.exit-btn {
  background: #dc3545;
  color: white;
  border: none;
  padding: 5px 15px;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
}

.presentation-view {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.slide-container {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>