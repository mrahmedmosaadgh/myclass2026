<template>
  <div v-if="modelValue && element" class="modal-backdrop" @click="$emit('update:modelValue', false)">
    <div class="settings-modal" @click.stop>
      <h3>Element Settings</h3>

      <!-- Common settings for all element types -->
      <div class="settings-section">
        <h4>{{ element.type.charAt(0).toUpperCase() + element.type.slice(1) }} Element</h4>
      </div>

      <!-- Video-specific settings -->
      <div v-if="element.type === 'video'" class="settings-section">
        <p>
          <label>
            YouTube URL:
            <input
              type="text"
              :value="element.videoUrl || ''"
              placeholder="https://www.youtube.com/watch?v=..."
              @change="updateVideoUrl($event.target.value)"
              class="full-width-input"
            >
          </label>
        </p>
        <p class="help-text">Enter a YouTube video URL to embed it in your presentation.</p>
        <div v-if="element.videoUrl" class="video-preview">
          <p>Video Preview:</p>
          <div class="video-container">
            <iframe
              :src="getEmbedUrl(element.videoUrl)"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
          </div>
        </div>
      </div>

      <!-- Text and List styling options -->
      <div v-if="element.type !== 'video'" class="settings-section">
        <p>
          <label>
            Text Color:
            <input
              type="color"
              :value="element.style.color"
              @change="updateStyle('color', $event.target.value)"
            >
          </label>
        </p>
        <p>
          <label>
            Background Color:
            <input
              type="color"
              :value="element.style.backgroundColor"
              @change="updateStyle('backgroundColor', $event.target.value)"
            >
          </label>
        </p>
        <p>
          <label>
            Font Size:
            <input
              type="number"
              :value="parseInt(element.style.fontSize)"
              min="8"
              max="72"
              step="1"
              style="width: 60px"
              @change="updateStyle('fontSize', $event.target.value + 'px')"
            >
            px
          </label>
        </p>
      </div>

      <div class="modal-footer">
        <button @click="$emit('update:modelValue', false)" class="close-button">Close</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  modelValue: Boolean,
  element: {
    type: Object,
    required: true,
    default: () => ({
      type: 'text',
      style: {
        color: '#000000',
        backgroundColor: '#ffffff',
        fontSize: '16px'
      },
      videoUrl: ''
    })
  }
});

const emit = defineEmits(['update:modelValue', 'updateStyle', 'update:element']);

const updateStyle = (property, value) => {
  emit('updateStyle', { property, value });
};

const updateVideoUrl = (url) => {
  // Create a copy of the element with the updated videoUrl
  const updatedElement = { ...props.element, videoUrl: url };

  // Update the content to display the embedded video
  if (url) {
    updatedElement.content = `<div class="video-embed-container">${getEmbedHtml(url)}</div>`;
  } else {
    updatedElement.content = '<div class="video-placeholder">Enter YouTube URL</div>';
  }

  // Emit the updated element
  emit('update:element', updatedElement);
};

const getEmbedUrl = (url) => {
  // Extract video ID from various YouTube URL formats
  let videoId = '';

  if (url.includes('youtube.com/watch')) {
    const urlParams = new URLSearchParams(new URL(url).search);
    videoId = urlParams.get('v');
  } else if (url.includes('youtu.be/')) {
    videoId = url.split('youtu.be/')[1]?.split('?')[0];
  } else if (url.includes('youtube.com/embed/')) {
    videoId = url.split('youtube.com/embed/')[1]?.split('?')[0];
  }

  if (!videoId) return '';

  // Return the embed URL with the video ID
  return `https://www.youtube.com/embed/${videoId}`;
};

const getEmbedHtml = (url) => {
  const embedUrl = getEmbedUrl(url);
  if (!embedUrl) return '';

  return `<iframe
    src="${embedUrl}"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    allowfullscreen
    style="width: 100%; height: 100%;"
  ></iframe>`;
};
</script>

<style scoped>
.settings-modal {
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
}

.settings-section {
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid #eee;
}

.settings-section h4 {
  margin-top: 0;
  margin-bottom: 15px;
  color: #333;
}

.full-width-input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.help-text {
  font-size: 0.9em;
  color: #666;
  margin-top: 5px;
}

.video-preview {
  margin-top: 15px;
}

.video-container {
  position: relative;
  padding-bottom: 56.25%; /* 16:9 aspect ratio */
  height: 0;
  overflow: hidden;
  margin-top: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.video-container iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.modal-footer {
  margin-top: 20px;
  text-align: right;
}

.close-button {
  padding: 8px 16px;
  background-color: #4a5568;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.close-button:hover {
  background-color: #2d3748;
}
</style>
