<template>
  <div
    class="canvas-editor"
    :class="{ 'presentation-mode': presentationMode }"
  >
    <div class="elements-container">
      <ElementContent
        v-for="element in modelValue.elements"
        :key="element.id"
        :element="element"
        :readonly="presentationMode || readonly"
      />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import ElementContent from './ElementContent.vue';

const props = defineProps({
  modelValue: {
    type: Object,
    required: true,
    default: () => ({
      elements: [],
      backgroundImage: ''
    })
  },
  presentationMode: {
    type: Boolean,
    default: false
  },
  readonly: {
    type: Boolean,
    default: false
  }
});
</script>

<style scoped>
.canvas-editor {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
}

.presentation-mode {
  background-color: white;
}

.elements-container {
  position: relative;
  width: 100%;
  height: 100%;
}
</style>











