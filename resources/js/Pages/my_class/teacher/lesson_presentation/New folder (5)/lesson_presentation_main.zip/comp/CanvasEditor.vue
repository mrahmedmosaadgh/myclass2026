<template>
    <div class="canvas-container" :class="{ 'presentation-mode': presentationMode }">
      <!-- Add controls panel -->
      <div class="controls-panel" v-if="!readonly">
        <input type="file" id="bgInput" accept="image/*" style="display: none" @change="handleBackgroundImage">
        <button @click="$refs.bgInput.click()">Choose Background</button>
        <button @click="toggleAllElements">Show/Hide All</button>

        <!-- Element type selector -->
        <div class="element-type-selector">
          <button
            @click="currentElementType = 'text'; addNewElement(20, 20, 'text')"
            :class="{ active: currentElementType === 'text' }"
            title="Add Text Element"
          >
            <span class="icon-text">T</span>
            Text
          </button>
          <button
            @click="currentElementType = 'list'; addNewElement(20, 20, 'list')"
            :class="{ active: currentElementType === 'list' }"
            title="Add List Element"
          >
            <span class="icon-list">≡</span>
            List
          </button>
          <button
            @click="currentElementType = 'video'; addNewElement(20, 20, 'video')"
            :class="{ active: currentElementType === 'video' }"
            title="Add Video Element"
          >
            <span class="icon-video">▶</span>
            Video
          </button>
        </div>
        <select v-model="zoomLevel" @change="handleZoomChange">
          <option value="fit">Fit Width</option>
          <option value="0.5">50%</option>
          <option value="1">100%</option>
          <option value="1.2">120%</option>
          <option value="1.5">150%</option>
          <option value="2">200%</option>
          <option value="2.5">250%</option>
        </select>
         </div>

      <div
        id="canvas"
        ref="canvasRef"
        class="canvas"
        :style="{
          backgroundImage: backgroundImage,
          backgroundSize: 'contain',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center',
          minHeight: `${canvasHeight}vh`,
          transform: `scale(${zoomLevel})`,
          transformOrigin: 'center center'
        }"
        @click="!readonly && handleCanvasClick"
      >
        <div
          v-for="(element, index) in elements"
          :key="element.id || index"
          class="element-container"
          :style="{
            left: `${element.x}%`,
            top: `${element.y}%`,
            // pointerEvents: readonly ? 'none' : 'auto'
          }"
          :data-id="index"
          :data-locked="element.locked"
        >
          <div class="drag-handle" >
            <button
              class="control-button visibility"
              @click.stop="toggleElement(element.id)"
              :class="{ 'visible': element.visible, 'hidden': !element.visible }"
              :title="element.visible ? 'Hide element' : 'Show element'"
            >
              <span class="eye-icon"></span>
            </button>
            <span v-if="!readonly"
              class="drag-icon"
              :style="{
                opacity: element.visible ? '1' : '0.3',
                filter: element.visible ? 'none' : 'blur(1px)',
                transition: 'opacity 0.3s ease, filter 0.3s ease'
              }"
              @mousedown="!element.locked && element.visible && startDrag($event, element)"
            >↔</span>
          </div>

          <div class="controls" v-if="!readonly">
            <button
              class="control-button copy"
              @click="copyElement(element.id)"
              :style="{ opacity: element.visible ? '1' : '0.3' }"
              title="Duplicate element"
            >
              <span class="icon-copy"></span>
            </button>
            <button
              class="control-button lock"
              @click="toggleLock(element.id)"
              :class="{ 'locked': element.locked }"
              :style="{ opacity: element.visible ? '1' : '0.3' }"
              :title="element.locked ? 'Unlock element' : 'Lock element'"
            >
              <span class="icon-lock"></span>
            </button>
            <button
              class="control-button settings"
              @click="openSettings(element)"
              :style="{ opacity: element.visible ? '1' : '0.3' }"
              title="Element settings"
            >
              <span class="icon-settings"></span>
            </button>
            <button
              class="control-button delete"
              @click="deleteElement(element.id)"
              :style="{ opacity: element.visible ? '1' : '0.3' }"
              title="Delete element"
            >
              <span class="icon-delete"></span>
            </button>
          </div>

          <div
            class="element-content"
            :contenteditable="!readonly && !element.locked && element.type !== 'video'"
            :class="{
              'element-hidden': !element.visible,
              'video-element': element.type === 'video'
            }"
            :style="{
              ...element.style,
              opacity: element.visible ? '1' : '0.3',
              filter: element.visible ? 'none' : 'blur(10px)',
              transition: 'opacity 0.3s ease, filter 0.3s ease'
            }"
            @blur="updateContent(element, $event)"
            v-html="element.content"
          ></div>
        </div>
      </div>

      <ElementSettingsModal
        v-if="showSettings && selectedElement && !readonly"
        v-model="showSettings"
        :element="selectedElement"
        @update-style="updateElementStyle"
        @update:element="updateElement"
      />
    </div>
  </template>

  <script setup>
  import { ref, onMounted, onUnmounted, watch } from 'vue';
  import ElementSettingsModal from './ElementSettingsModal.vue';
  import { toast } from 'vue3-toastify';

  // Add zoomLevel ref
  const zoomLevel = ref(1);

  const props = defineProps({
    modelValue: {
      type: Object,
      default: () => ({
        elements: [],
        backgroundImage: ''
      })
    },
    presentationMode: {
      type: Boolean,
      default: false
    },
    readonly: {
      type: Boolean,
      default: false
    }
  });

  const emit = defineEmits(['update:modelValue']);

  // Initialize refs
  const elements = ref([]);
  const isDragging = ref(false);
  const currentElement = ref(null);
  const offset = ref({ x: 0, y: 0 });
  const showSettings = ref(false);
  const selectedElement = ref(null);
  const canvasHeight = ref(100);
  const backgroundImage = ref('');
  const canvasRef = ref(null);
  const currentElementType = ref('text'); // Default element type

  // Safe initialization of elements
  const initializeElements = () => {
    try {
      elements.value = Array.isArray(props.modelValue?.elements)
        ? [...props.modelValue.elements]
        : [];
      backgroundImage.value = props.modelValue?.backgroundImage || '';
    } catch (error) {
      console.error('Error initializing elements:', error);
      elements.value = [];
      backgroundImage.value = '';
    }
  };

  // Save elements safely
  const saveElements = () => {
    try {
      emit('update:modelValue', {
        elements: elements.value,
        backgroundImage: backgroundImage.value
      });
    } catch (error) {
      console.error('Error saving elements:', error);
    }
  };

  const addNewElement = (x, y, type = 'text') => {
    let content = 'New Element';
    let style = {
      color: '#000000',
      backgroundColor: '#ffffff',
      fontSize: '16px'
    };

    // Set default content based on element type
    if (type === 'list') {
      content = '<ul><li>List item 1</li><li>List item 2</li></ul>';
    } else if (type === 'video') {
      content = '<div class="video-placeholder">Enter YouTube URL</div>';
      style = {
        ...style,
        width: '320px',
        height: '180px',
        padding: '0'
      };
    }

    const element = {
      id: Date.now(),
      type,
      content,
      x: Math.max(0, Math.min(90, x)),
      y: Math.max(0, y),
      visible: true,
      locked: false,
      style,
      // For video elements
      videoUrl: type === 'video' ? '' : undefined
    };

    elements.value.push(element);

    // If it's a video element, open settings immediately
    if (type === 'video') {
      selectedElement.value = element;
      showSettings.value = true;
    }

    saveElements();
  };

  const handleCanvasClick = (e) => {
    if (e.target === canvasRef.value) {
      const rect = canvasRef.value.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      addNewElement(x, y, currentElementType.value);
    }
  };

  const toggleElement = (id) => {
    const element = elements.value.find(el => el.id === id);
    if (element) {
      element.visible = !element.visible;
      saveElements();
    }
  };

  const copyElement = (id) => {
    const element = elements.value.find(el => el.id === id);
    if (element) {
      const newElement = {
        ...element,
        id: Date.now(),
        x: element.x + 5,
        y: element.y + 5
      };
      elements.value.push(newElement);
      saveElements();
    }
  };

  const deleteElement = (id) => {
    elements.value = elements.value.filter(el => el.id !== id);
    saveElements();
  };

  const toggleLock = (id) => {
    const element = elements.value.find(el => el.id === id);
    if (element) {
      element.locked = !element.locked;
      saveElements();
    }
  };

  const openSettings = (element) => {
    if (element) {
      selectedElement.value = element;
      showSettings.value = true;
    }
  };

  const updateElementStyle = ({ property, value }) => {
    if (selectedElement.value) {
      selectedElement.value.style[property] = value;
      saveElements();
    }
  };

  const updateElement = (updatedElement) => {
    if (selectedElement.value) {
      // Find the element in the elements array and update it
      const index = elements.value.findIndex(el => el.id === updatedElement.id);
      if (index !== -1) {
        elements.value[index] = updatedElement;
        selectedElement.value = updatedElement; // Update the selected element reference
        saveElements();
      }
    }
  };

  const updateContent = (element, event) => {
    // Don't update content for video elements on blur
    // as it would overwrite the video embed
    if (element.type !== 'video') {
      element.content = event.target.innerHTML;
      saveElements();
    }
  };

  const startDrag = (e, element) => {
    e.stopPropagation();
    isDragging.value = true;
    currentElement.value = element;
    const rect = e.target.getBoundingClientRect();
    offset.value = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const handleMouseMove = (e) => {
    if (!isDragging.value || !currentElement.value) return;

    const canvas = canvasRef.value;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - offset.value.x - rect.left) / rect.width) * 100;
    const y = ((e.clientY - offset.value.y - rect.top) / rect.height) * 100;

    currentElement.value.x = Math.max(0, Math.min(90, x));
    currentElement.value.y = Math.max(0, y);
  };

  const handleMouseUp = () => {
    if (isDragging.value) {
      isDragging.value = false;
      currentElement.value = null;
      saveElements();
    }
  };

  const toggleAllElements = () => {
    const allHidden = elements.value.every(el => !el.visible);
    elements.value.forEach(el => el.visible = allHidden);
    saveElements();
  };

  const handleZoomChange = () => {
    if (zoomLevel.value === 'fit') {
      // Implement fit width logic
      // For now, we'll just set a reasonable default
      zoomLevel.value = 1;
    } else {
      // No need to store in a separate variable since we're using it directly
      // from zoomLevel.value
    }
  };

  const handleBackgroundImage = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        backgroundImage.value = `url(${e.target.result})`;
        saveElements();
      };
      reader.readAsDataURL(file);
    }
  };




  onMounted(() => {
    try {
      initializeElements();

      if (!props.readonly) {
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
      }
    } catch (error) {
      console.error('Error in onMounted:', error);
    }
  });

  onUnmounted(() => {
    try {
      if (!props.readonly) {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      }
    } catch (error) {
      console.error('Error in onUnmounted:', error);
    }
  });

  watch(() => props.modelValue, (newValue) => {
    try {
      if (newValue) {
        initializeElements();
      }
    } catch (error) {
      console.error('Error in modelValue watcher:', error);
    }
  }, { deep: true });

  // Add zoom methods
  const zoomIn = () => {
    zoomLevel.value = Math.min(zoomLevel.value + 0.1, 2);
  };

  const zoomOut = () => {
    zoomLevel.value = Math.max(zoomLevel.value - 0.1, 0.5);
  };

  const resetZoom = () => {
    zoomLevel.value = 1;
  };
  </script>

  <style scoped>
  .canvas-container {
    position: relative;
    width: 100%;
    height: 100%;
  }

  .canvas-container.presentation-mode {
    background: #000;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .canvas {
    position: relative;
    width: 100%;
    min-height: 100vh;
    background: white;
    transition: transform 0.2s ease-in-out;
  }

  .element-container {
    position: absolute;
    padding: 5px;
    transition: transform 0.3s ease;
  }

  .element-container:hover {
    z-index: 10;
  }

  .drag-handle {
    cursor: move;
    padding: 2px;
    display: flex;
    align-items: center;
    gap: 5px;
  }

  .controls {
    display: flex;
    gap: 6px;
    margin-top: 5px;
    padding: 2px;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.5);
  }

  .control-button {
    cursor: pointer;
    border: none;
    background: rgba(255, 255, 255, 0.8);
    padding: 4px;
    border-radius: 4px;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    color: #4b5563;
  }

  .control-button:hover {
    background: white;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .control-button.copy:hover {
    color: #6366f1;
  }

  .control-button.lock:hover {
    color: #f59e0b;
  }

  .control-button.settings:hover {
    color: #3b82f6;
  }

  .control-button.delete:hover {
    color: #ef4444;
  }

  .control-button.lock.locked {
    background: rgba(245, 158, 11, 0.2);
    color: #92400e;
  }

  .control-button.visibility {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    border: 1px solid rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
  }

  .control-button.visibility.visible {
    background: rgba(16, 185, 129, 0.2);
  }

  .control-button.visibility.hidden {
    background: rgba(239, 68, 68, 0.2);
  }

  .eye-icon {
    position: relative;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: transparent;
    border: 2px solid currentColor;
    display: inline-block;
  }

  .eye-icon::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: currentColor;
    transition: all 0.3s ease;
  }

  .control-button.visibility.hidden .eye-icon::after {
    content: '';
    position: absolute;
    top: 50%;
    left: -2px;
    width: 18px;
    height: 2px;
    background: rgba(239, 68, 68, 0.8);
    transform: rotate(45deg);
  }

  /* Copy icon */
  .icon-copy {
    position: relative;
    width: 14px;
    height: 14px;
    border: 2px solid currentColor;
    border-radius: 2px;
    display: inline-block;
  }

  .icon-copy::after {
    content: '';
    position: absolute;
    top: -4px;
    left: 4px;
    width: 14px;
    height: 14px;
    border: 2px solid currentColor;
    border-radius: 2px;
    background: white;
    z-index: -1;
  }

  /* Lock icon */
  .icon-lock {
    position: relative;
    width: 12px;
    height: 8px;
    border: 2px solid currentColor;
    border-radius: 2px;
    display: inline-block;
    margin-top: 6px;
  }

  .icon-lock::before {
    content: '';
    position: absolute;
    top: -8px;
    left: 2px;
    width: 4px;
    height: 8px;
    border: 2px solid currentColor;
    border-bottom: none;
    border-radius: 4px 4px 0 0;
  }

  .control-button.lock.locked .icon-lock::before {
    left: 2px;
  }

  /* Settings icon */
  .icon-settings {
    position: relative;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 2px solid currentColor;
    display: inline-block;
  }

  .icon-settings::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 4px;
    height: 4px;
    border-radius: 50%;
    background: currentColor;
  }

  .icon-settings::after {
    content: '';
    position: absolute;
    top: -4px;
    left: 50%;
    transform: translateX(-50%);
    width: 2px;
    height: 4px;
    background: currentColor;
    box-shadow: 0 14px 0 currentColor, 7px 7px 0 currentColor, -7px 7px 0 currentColor, 7px -7px 0 currentColor, -7px -7px 0 currentColor;
  }

  /* Delete icon */
  .icon-delete {
    position: relative;
    width: 14px;
    height: 14px;
    display: inline-block;
  }

  .icon-delete::before, .icon-delete::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    width: 14px;
    height: 2px;
    background: currentColor;
  }

  .icon-delete::before {
    transform: rotate(45deg);
  }

  .icon-delete::after {
    transform: rotate(-45deg);
  }

  .element-content {
    min-width: 50px;
    min-height: 20px;
    padding: 5px;
    margin-top: 5px;
    border: 1px solid transparent;
  }

  .element-content:focus {
    border-color: #4a5568;
    outline: none;
  }

  .element-hidden {
    pointer-events: none;
    user-select: none;
  }

  .controls-panel {
    padding: 10px;
    background-color: #f5f5f5;
    border-bottom: 1px solid #ddd;
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
  }

  .controls-panel button {
    padding: 5px 10px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
  }

  .controls-panel button:hover {
    background-color: #f0f0f0;
  }

  .controls-panel select {
    padding: 5px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .zoom-controls {
    position: absolute;
    bottom: 20px;
    right: 20px;
    display: flex;
    gap: 8px;
  }

  .zoom-controls button {
    padding: 4px 8px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
  }

  .zoom-controls button:hover {
    background: #f5f5f5;
  }

  /* Element type selector */
  .element-type-selector {
    display: flex;
    gap: 5px;
    margin-right: 10px;
  }

  .element-type-selector button {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 6px 12px;
    border-radius: 4px;
    border: 1px solid #ddd;
    background: white;
    cursor: pointer;
    transition: all 0.2s ease;
  }

  .element-type-selector button:hover {
    background: #f0f0f0;
  }

  .element-type-selector button.active {
    background: #e0e7ff;
    border-color: #818cf8;
    color: #4338ca;
  }

  .element-type-selector .icon-text,
  .element-type-selector .icon-list,
  .element-type-selector .icon-video {
    font-size: 16px;
    font-weight: bold;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 20px;
    height: 20px;
  }

  /* Video element styles */
  .video-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    min-height: 180px;
    background: #f0f0f0;
    border: 1px dashed #ccc;
    color: #666;
    font-size: 14px;
    text-align: center;
    padding: 20px;
  }

  .video-embed-container {
    width: 100%;
    height: 100%;
    min-width: 320px;
    min-height: 180px;
    overflow: hidden;
    border-radius: 4px;
    position: relative;
  }

  .video-embed-container iframe,
  .youtube-iframe {
    width: 100%;
    height: 100%;
    border: none;
    position: absolute;
    top: 0;
    left: 0;
  }

  .video-wrapper {
    position: relative;
    width: 100%;
    height: 100%;
    min-height: 180px;
    padding-bottom: 56.25%; /* 16:9 aspect ratio */
    overflow: hidden;
  }

  .video-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.1);
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .video-overlay:hover {
    opacity: 1;
  }

  .play-button-overlay {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background-color: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: transform 0.2s ease, background-color 0.2s ease;
  }

  .play-button-overlay:hover {
    transform: scale(1.1);
    background-color: rgba(0, 0, 0, 0.8);
  }

  .play-button-overlay.playing {
    background-color: rgba(229, 62, 62, 0.8);
  }

  .play-icon {
    width: 30px;
    height: 30px;
    color: white;
  }

  /* Specific styles for video elements */
  .video-element {
    min-width: 320px;
    min-height: 180px;
    padding: 0 !important;
    overflow: hidden;
  }

  /* Ensure scripts inside elements don't display */
  .element-content script {
    display: none;
  }
  </style>









