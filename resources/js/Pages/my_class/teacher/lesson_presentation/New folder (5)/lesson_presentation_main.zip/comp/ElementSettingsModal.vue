<template>
  <div v-if="modelValue && element" class="modal-backdrop" @click="$emit('update:modelValue', false)">
    <div class="settings-modal" @click.stop>
      <h3>Element Settings</h3>

      <!-- Common settings for all element types -->
      <div class="settings-section">
        <h4>{{ element.type.charAt(0).toUpperCase() + element.type.slice(1) }} Element</h4>
      </div>

      <!-- Video-specific settings -->
      <div v-if="element.type === 'video'" class="settings-section">
        <p>
          <label>
            YouTube URL:
            <input
              type="text"
              :value="element.videoUrl || ''"
              placeholder="https://www.youtube.com/watch?v=..."
              @change="updateVideoUrl($event.target.value)"
              class="full-width-input"
            >
          </label>
        </p>
        <p class="help-text">Enter a YouTube video URL to embed it in your presentation.</p>
        <div v-if="element.videoUrl" class="video-preview">
          <p>Video Preview:</p>
          <div class="video-container">
            <iframe
              :src="getEmbedUrl(element.videoUrl)"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen
            ></iframe>
          </div>
        </div>
      </div>

      <!-- Text and List styling options -->
      <div v-if="element.type !== 'video'" class="settings-section">
        <p>
          <label>
            Text Color:
            <input
              type="color"
              :value="element.style.color"
              @change="updateStyle('color', $event.target.value)"
            >
          </label>
        </p>
        <p>
          <label>
            Background Color:
            <input
              type="color"
              :value="element.style.backgroundColor"
              @change="updateStyle('backgroundColor', $event.target.value)"
            >
          </label>
        </p>
        <p>
          <label>
            Font Size:
            <input
              type="number"
              :value="parseInt(element.style.fontSize)"
              min="8"
              max="72"
              step="1"
              style="width: 60px"
              @change="updateStyle('fontSize', $event.target.value + 'px')"
            >
            px
          </label>
        </p>
      </div>

      <div class="modal-footer">
        <button @click="$emit('update:modelValue', false)" class="close-button">Close</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  modelValue: Boolean,
  element: {
    type: Object,
    required: true,
    default: () => ({
      type: 'text',
      style: {
        color: '#000000',
        backgroundColor: '#ffffff',
        fontSize: '16px'
      },
      videoUrl: ''
    })
  }
});

const emit = defineEmits(['update:modelValue', 'updateStyle', 'update:element']);

const updateStyle = (property, value) => {
  emit('updateStyle', { property, value });
};

const updateVideoUrl = (url) => {
  // Create a copy of the element with the updated videoUrl
  const updatedElement = { ...props.element, videoUrl: url };

  // Update the content to display the embedded video
  if (url) {
    updatedElement.content = `<div class="video-embed-container">${getEmbedHtml(url)}</div>`;
  } else {
    updatedElement.content = '<div class="video-placeholder">Enter YouTube URL</div>';
  }

  // Emit the updated element
  emit('update:element', updatedElement);
};

const getEmbedUrl = (url) => {
  // Extract video ID from various YouTube URL formats
  let videoId = '';

  if (url.includes('youtube.com/watch')) {
    const urlParams = new URLSearchParams(new URL(url).search);
    videoId = urlParams.get('v');
  } else if (url.includes('youtu.be/')) {
    videoId = url.split('youtu.be/')[1]?.split('?')[0];
  } else if (url.includes('youtube.com/embed/')) {
    videoId = url.split('youtube.com/embed/')[1]?.split('?')[0];
  }

  if (!videoId) return '';

  // Return the embed URL with the video ID and parameters for better control
  // enablejsapi=1 allows JavaScript API control
  // rel=0 prevents showing related videos
  // modestbranding=1 shows minimal YouTube branding
  return `https://www.youtube.com/embed/${videoId}?enablejsapi=1&rel=0&modestbranding=1&controls=1`;
};

const getEmbedHtml = (url) => {
  const embedUrl = getEmbedUrl(url);
  if (!embedUrl) return '';

  // Generate a unique ID for this iframe to reference it with the YouTube API
  const iframeId = `youtube-player-${Date.now()}`;

  // Create the HTML for the video embed
  // Using string concatenation to avoid template literal issues with embedded script
  return '<div class="video-wrapper">' +
    '<iframe ' +
    'id="' + iframeId + '" ' +
    'src="' + embedUrl + '" ' +
    'frameborder="0" ' +
    'allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" ' +
    'allowfullscreen ' +
    'class="youtube-iframe">' +
    '</iframe>' +
    '<div class="video-overlay" data-iframe-id="' + iframeId + '" onclick="handleVideoClick(this)">' +
    '<div class="play-button-overlay">' +
    '<svg viewBox="0 0 24 24" class="play-icon">' +
    '<path fill="currentColor" d="M8,5.14V19.14L19,12.14L8,5.14Z" />' +
    '</svg>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '<scr' + 'ipt>' +
    '// Add YouTube API script if not already added\n' +
    'if (!window.YT) {\n' +
    '  const tag = document.createElement("script");\n' +
    '  tag.src = "https://www.youtube.com/iframe_api";\n' +
    '  const firstScriptTag = document.getElementsByTagName("script")[0];\n' +
    '  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\n' +
    '}\n\n' +
    '// Store player instances\n' +
    'window.ytPlayers = window.ytPlayers || {};\n\n' +
    '// This function will be called when the iframe is clicked\n' +
    'function handleVideoClick(overlay) {\n' +
    '  const iframeId = overlay.getAttribute("data-iframe-id");\n' +
    '  const iframe = document.getElementById(iframeId);\n' +
    '  if (!iframe) return;\n\n' +
    '  const playButton = overlay.querySelector(".play-button-overlay");\n\n' +
    '  // If we already have a player instance\n' +
    '  if (window.ytPlayers[iframeId]) {\n' +
    '    const player = window.ytPlayers[iframeId];\n' +
    '    const state = player.getPlayerState();\n\n' +
    '    // If playing, pause. If paused or ended, play.\n' +
    '    if (state === YT.PlayerState.PLAYING) {\n' +
    '      player.pauseVideo();\n' +
    '      if (playButton) playButton.classList.remove("playing");\n' +
    '    } else {\n' +
    '      player.playVideo();\n' +
    '      if (playButton) playButton.classList.add("playing");\n' +
    '    }\n' +
    '  } else {\n' +
    '    // Initialize the player if it doesn\'t exist\n' +
    '    // We need to wait for the YouTube API to load\n' +
    '    if (window.YT && window.YT.Player) {\n' +
    '      initPlayer(iframeId, playButton);\n' +
    '    } else {\n' +
    '      // If YouTube API isn\'t loaded yet, wait for it\n' +
    '      window.onYouTubeIframeAPIReady = function() {\n' +
    '        initPlayer(iframeId, playButton);\n' +
    '      };\n' +
    '    }\n' +
    '  }\n' +
    '}\n\n' +
    '// Initialize a YouTube player\n' +
    'function initPlayer(iframeId, playButton) {\n' +
    '  window.ytPlayers[iframeId] = new YT.Player(iframeId, {\n' +
    '    events: {\n' +
    '      \'onStateChange\': function(event) {\n' +
    '        // Update play button based on player state\n' +
    '        if (event.data === YT.PlayerState.PLAYING) {\n' +
    '          if (playButton) playButton.classList.add("playing");\n' +
    '        } else if (event.data === YT.PlayerState.PAUSED || event.data === YT.PlayerState.ENDED) {\n' +
    '          if (playButton) playButton.classList.remove("playing");\n' +
    '        }\n' +
    '      },\n' +
    '      \'onReady\': function(event) {\n' +
    '        // Play video when player is ready\n' +
    '        event.target.playVideo();\n' +
    '        if (playButton) playButton.classList.add("playing");\n' +
    '      }\n' +
    '    }\n' +
    '  });\n' +
    '}\n' +
    '</scr' + 'ipt>';
};
</script>

<style scoped>
.settings-modal {
  max-width: 500px;
  max-height: 80vh;
  overflow-y: auto;
}

.settings-section {
  margin-bottom: 20px;
  padding-bottom: 15px;
  border-bottom: 1px solid #eee;
}

.settings-section h4 {
  margin-top: 0;
  margin-bottom: 15px;
  color: #333;
}

.full-width-input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.help-text {
  font-size: 0.9em;
  color: #666;
  margin-top: 5px;
}

.video-preview {
  margin-top: 15px;
}

.video-container {
  position: relative;
  padding-bottom: 56.25%; /* 16:9 aspect ratio */
  height: 0;
  overflow: hidden;
  margin-top: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.video-container iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.modal-footer {
  margin-top: 20px;
  text-align: right;
}

.close-button {
  padding: 8px 16px;
  background-color: #4a5568;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.close-button:hover {
  background-color: #2d3748;
}
</style>
