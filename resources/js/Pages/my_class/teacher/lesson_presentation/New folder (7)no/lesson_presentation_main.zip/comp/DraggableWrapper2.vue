<template>
  <div
    class="draggable-wrapper group"
    :style="{
      position: 'absolute',
      left: `${modelValue.x}px`,
      top: `${modelValue.y}px`,
      opacity: modelValue.visible ? 1 : 0.3,
      zIndex: isDragging ? 50 : 1
    }"
  >
    <!-- Drag Handle -->
    <div
      v-if="!hideDragHandle"
      class="drag-handle"
      :class="[
        'absolute -top-2 -left-2 w-8 h-8 rounded-full flex items-center justify-center cursor-move z-50 transition-all duration-200',
        isDragging ? 'bg-indigo-600' : 'bg-gray-500 hover:bg-gray-600',
        showHandle ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
      ]"
      @mousedown="startDrag"
      :title="dragTitle"
    >
      <LucideIcon
        :name="dragIconName"
        class="w-4 h-4 text-white"
        :class="{ 'animate-spin': isDragging }"
      />
    </div>

    <!-- Content Slot -->
    <div
      class="draggable-content"
      :class="{ 'pointer-events-none': isDragging }"
    >
      <slot></slot>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import LucideIcon from '@/Components/Common/LucideIcon.vue';

const props = defineProps({
  modelValue: {
    type: Object,
    required: true,
    default: () => ({
      x: 0,
      y: 0,
      visible: true
    })
  },
  constraints: {
    type: Object,
    default: () => ({
      minX: -100,
      maxX: 3000,
      minY: -50,
      maxY: 850
    })
  },
  showHandle: {
    type: Boolean,
    default: true
  },
  hideDragHandle: {
    type: Boolean,
    default: false
  },
  dragIconName: {
    type: String,
    default: 'grip'
  },
  dragTitle: {
    type: String,
    default: 'Drag to move'
  }
});

const emit = defineEmits(['update:modelValue', 'drag-start', 'drag-end']);

const isDragging = ref(false);
const startX = ref(0);
const startY = ref(0);
const elementX = ref(0);
const elementY = ref(0);

const startDrag = (event) => {
  isDragging.value = true;
  startX.value = event.clientX;
  startY.value = event.clientY;
  elementX.value = props.modelValue.x;
  elementY.value = props.modelValue.y;

  document.addEventListener('mousemove', handleDrag);
  document.addEventListener('mouseup', stopDrag);

  emit('drag-start');
};

const handleDrag = (event) => {
  if (!isDragging.value) return;

  const dx = event.clientX - startX.value;
  const dy = event.clientY - startY.value;

  let newX = Math.max(props.constraints.minX,
                Math.min(props.constraints.maxX, elementX.value + dx));
  let newY = Math.max(props.constraints.minY,
                Math.min(props.constraints.maxY, elementY.value + dy));

  emit('update:modelValue', {
    ...props.modelValue,
    x: newX,
    y: newY
  });
};

const stopDrag = () => {
  isDragging.value = false;
  document.removeEventListener('mousemove', handleDrag);
  document.removeEventListener('mouseup', stopDrag);
  emit('drag-end');
};
</script>

<style scoped>
.draggable-wrapper {
  min-width: 20px;
  min-height: 20px;
  user-select: none;
}

.draggable-content {
  position: relative;
  display: inline-block;
  min-width: min-content;
}

.drag-handle {
  cursor: move;
  user-select: none;
}
</style>


