<template>
  <div class="canvas-container" :class="{ 'thumbnail-mode': thumbnail }">
    <!-- Zoom controls -->
    <div v-if="!thumbnail" class="zoom-controls">
      <select class="zoom-select" @change="e => handleZoomChange(e.target.value)">
        <option value="0.5">50%</option>
        <option value="1">100%</option>
        <option value="1.2">120%</option>
        <option value="1.5">150%</option>
        <option value="2">200%</option>
        <option value="2.5">250%</option>
        <option value="fit">Fit</option>
      </select>
    </div>

    <!-- Canvas -->
    <div
      id="canvas"
      class="canvas"
      :style="{
        transform: `scale(${zoomLevel})`,
        transformOrigin: '0 0'
      }"
    >
      <div class="canvas-content">
        <DraggableWrapper2
          v-for="element in content.elements"
          :key="element.id"
          :modelValue="{
            x: element.x,
            y: element.y,
            visible: element.visible
          }"
          :constraints="{
            minX: -100,
            maxX: 3000,
            minY: -50,
            maxY: 850
          }"
          :show-handle="!readonly"
          :hide-drag-handle="readonly || element.locked"
          drag-icon-name="move"
          @drag-start="handleDragStart(element)"
          @drag-end="handleDragEnd(element)"
          @update:modelValue="updateElementPosition(element, $event)"
        >
          <ElementContent
            :element="element"
            :readonly="readonly"
            @update="handleContentUpdate"
          />
        </DraggableWrapper2>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, onUnmounted } from 'vue';
import DraggableWrapper2 from './DraggableWrapper2.vue';
import ElementContent from './ElementContent.vue';
import LucideIcon from '@/Components/Common/LucideIcon.vue';

const isDragging = ref(false);

const props = defineProps({
  readonly: {
    type: Boolean,
    default: false
  },
  thumbnail: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(['update:modelValue', 'canvas-click', 'delete-element']);

// Define zoom-related state
const zoomLevel = ref(1);
const CANVAS_DEFAULT_WIDTH = 1200;

// Calculate fit width based on container size
const calculateFitWidth = () => {
  const container = document.querySelector('.canvas-container');
  if (!container) return 1;
  const containerWidth = container.clientWidth - 40; // Subtract padding
  return containerWidth / CANVAS_DEFAULT_WIDTH;
};

// Zoom control functions
const setZoom = (value) => {
  zoomLevel.value = value;
  const canvas = document.getElementById('canvas');
  if (canvas) {
    canvas.style.transform = `scale(${value})`;
  }

  // Update select element to reflect current zoom
  const zoomSelect = document.querySelector('.zoom-select');
  if (zoomSelect) {
    if (Math.abs(value - calculateFitWidth()) < 0.01) {
      zoomSelect.value = 'fit';
    } else {
      const nearestPreset = findNearestPreset(value);
      zoomSelect.value = nearestPreset.toString();
    }
  }
};

const findNearestPreset = (value) => {
  const presets = [0.5, 1, 1.2, 1.5, 2, 2.5];
  return presets.reduce((prev, curr) =>
    Math.abs(curr - value) < Math.abs(prev - value) ? curr : prev
  );
};

const handleZoomChange = (value) => {
  if (value === 'fit') {
    setZoom(calculateFitWidth());
  } else {
    setZoom(parseFloat(value));
  }
};

// Initialize zoom level
onMounted(() => {
  if (props.thumbnail) {
    setZoom(0.2); // Small zoom for thumbnails
  } else {
    setZoom(calculateFitWidth()); // Fit width for normal view
  }
});

// Handle window resize
let resizeTimeout;
const handleResize = () => {
  clearTimeout(resizeTimeout);
  resizeTimeout = setTimeout(() => {
    if (!props.thumbnail && zoomLevel.value === calculateFitWidth()) {
      setZoom(calculateFitWidth());
    }
  }, 100);
};

onMounted(() => {
  if (!props.thumbnail) {
    window.addEventListener('resize', handleResize);
  }
});

onUnmounted(() => {
  if (!props.thumbnail) {
    window.removeEventListener('resize', handleResize);
  }
});

// Replace modelValue prop with defineModel
const content = defineModel({
  default: () => ({
    elements: [],
    backgroundImage: '',
    lastModified: Date.now()
  })
});

// Remove the watch and local content since we're using defineModel
// watch(() => props.modelValue, (newValue) => {
//   if (newValue) {
//     localContent.value = JSON.parse(JSON.stringify(newValue));
//   }
// }, { deep: true });
// 1111
const handleContentUpdate = ({ element, contentUpdate }) => {
  if (props.readonly) return;
  if (!element || contentUpdate === undefined) return;
  if (!content.value?.elements) {
    content.value = {
      elements: [],
      backgroundImage: '',
      lastModified: Date.now()
    };
  }

  const updatedElements = content.value.elements.map(el => {
    if (el.id === element.id) {
      return {
        ...el,
        content: contentUpdate,
        lastUpdated: Date.now()
      };
    }
    return el;
  });

  content.value = {
    ...content.value,
    elements: updatedElements,
    lastModified: Date.now()
  };
};

const updateElementPosition = (element, newPosition) => {
  if (!content.value?.elements) {
    content.value = {
      elements: [],
      backgroundImage: '',
      lastModified: Date.now()
    };
  }

  const updatedElements = content.value.elements.map(el => {
    if (el.id === element.id) {
      return {
        ...el,
        x: newPosition.x,
        y: newPosition.y
      };
    }
    return el;
  });

  content.value = {
    ...content.value,
    elements: updatedElements,
    lastModified: Date.now()
  };
};

const handleDragStart = (element) => {
  if (props.readonly || element.locked) return;
  isDragging.value = true;
};

const handleDragEnd = (element) => {
  if (props.readonly || element.locked) return;
  isDragging.value = false;
};
// 2222
// const handleContentUpdate = ({ element, contentUpdate }) => {
//   if (props.readonly) return;

//   if (!element || contentUpdate === undefined) return;

//   if (!content.value?.elements) return;

//   const updatedElements = content.value.elements.map(el => {
//     if (el.id === element.id) {
//       return {
//         ...el,
//         content: contentUpdate,
//         lastUpdated: Date.now()
//       };
//     }
//     return el;
//   });

//   if (JSON.stringify(content.value.elements) !== JSON.stringify(updatedElements)) {
//     content.value = {
//       ...content.value,
//       elements: updatedElements,
//       lastModified: Date.now()
//     };
//   }
// };
</script>

<style scoped>
.canvas-container {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: auto;
  background: #f0f0f0;
}

.thumbnail-mode {
  overflow: hidden;
  background: transparent;
}

.canvas {
  position: relative;
  width: 1200px;
  min-height: 675px;
  background: white;
  transform-origin: 0 0;
}

.zoom-controls {
  position: absolute;
  top: 10px;
  right: 10px;
  z-index: 1000;
}

.zoom-select {
  padding: 4px 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: white;
}
</style>


