
<template>
 <div class="relative w-36 h-48 mt-14 flex flex-col items-center">
  

  <!-- Avatar Card (Clickable) -->
  <div
    :class="[
      'student-card',
      selected || selectedId === student.id ? 'selected' : '',
      disableBehavior ? 'disabled-card' : ''
    ]"
    @click="!disableBehavior ? $emit('select', student.id) : null"
  >



    <!-- Name Layer Above Avatar -->
  <div class="absolute -top-10 text-center w-full z-20 name-container">
    <div 
	class="first-name"
	:class="selected || selectedId === student.id ? 'first-name' : '',disableBehavior ? 'disabled-first-name' : ''"
	
	>{{ student.firstName }}</div>
    <div class="last-name">{{ student.lastName }}</div>
  </div>




    <!-- Avatar Circle -->
    <img
      :src="student.avatar || placeholderAvatar(student.name)"
      class="student-avatar"
    />
  </div>

</div>


</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
	student: { type: Object, required: true },
	selected: { type: Boolean, default: false },
	selectedId: { type: [String, Number], default: null },
	cardClass: { type: [String, Object, Array], default: '' },
	studentSummary: { type: Object, default: () => ({ positive: 0, negative: 0, total: 0 }) },
	avatarEditEnabled: { type: Boolean, default: false },
	showAvatarButtons: { type: Boolean, default: false },
	disableBehavior: { type: Boolean, default: false }
})

const emit = defineEmits(['select', 'open-camera', 'open-behavior'])

function parseName(fullName) {
	if (!fullName || typeof fullName !== 'string') return { firstName: '', secondName: '', lastName: '' }
	const parts = fullName.trim().split(/\s+/).filter(p => p.length > 0)
	const firstName = parts[0] || ''
	const lastName = parts.length > 1 ? parts[parts.length - 1] : ''
	const secondName = parts.length > 2 ? parts.slice(1, -1).join(' ') : ''
	return { firstName, secondName, lastName }
}

function placeholderAvatar(name) {
	try {
		if (name) {
			const initials = name.split(' ').map(s => s[0] || '').slice(0, 2).join('').toUpperCase()
			const bgColor = '#e2e8f0'
			const textColor = '#475569'
			const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 96 96"><rect width="96" height="96" fill="${bgColor}" rx="48" ry="48"/><text x="48" y="48" dy="8" text-anchor="middle" font-family="Arial" font-size="32" font-weight="bold" fill="${textColor}">${initials}</text></svg>`
			return `data:image/svg+xml,${encodeURIComponent(svg)}`
		}
	} catch (e) {
		console.warn('Failed to generate avatar SVG:', e)
	}
	return '/images/avatars/default-avatar.svg'
}
</script>

<style scoped>
 
/* Name Above Avatar */
.name-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: -0.3rem;
}

.first-name {
  font-size: 1.1rem;
  font-weight: 700;
  color: #1e3a8a;
  background: #fde047;
  padding: 0.1rem 0.6rem;
  border-radius: 0.7rem;
  box-shadow: 0 1px 5px rgba(0,0,0,0.1);
}

.disabled-first-name {
  font-size: 1.1rem;
 
  color: #ffffff;
  background: #424242;
  padding: 0.1rem 0.6rem;
  border-radius: 0.7rem;
  box-shadow: 0 1px 5px rgba(0,0,0,0.1);
}
.last-name {
  font-size: 0.75rem;
  margin-top: -0.2rem;
  color: #475569;
}

/* Main Card Shell */
.student-card {
  width: 8rem;
  height: 8rem;
  border-radius: 50%;
  background: white;
  display: flex;
  align-items: center;
  justify-content: center;

  /* modern shadow */
  box-shadow: 0 5px 12px rgba(0,0,0,0.10);
  
  transition: all 0.3s ease;
  cursor: pointer;
  position: relative;
}

/* Avatar */
.student-avatar {
  width: 7.5rem;
  height: 7.5rem;
  border-radius: 50%;
  object-fit: cover;
  z-index: 5;
}

/* Hover Interaction */
.student-card:hover {
  transform: scale(1.04);
  box-shadow: 0 8px 25px rgba(0,0,0,0.15);
  z-index: 20;
}

/* Selected State: Light Glow Highlight */
.student-card.selected {
  box-shadow: 0 0 0 4px #2563eb,
              0 0 18px rgba(37, 99, 235, 0.5);
  transform: scale(1.08);
}

/* Disabled State: Subtle Noise + Dim Effect */
.disabled-card {
  pointer-events: none;
  opacity: 0.55;
  filter: contrast(0.7) brightness(0.9);
  background-image: url("data:image/svg+xml;base64,PHN2ZyBmaWxsPSIjMDAwMCIgZmlsbC1vcGFjaXR5PSIwLjA1IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyIiBoZWlnaHQ9IjIiPjxwYXRoIGQ9Ik0wIDBoMnYySDB6Ii8+PC9zdmc+");
}

</style>
