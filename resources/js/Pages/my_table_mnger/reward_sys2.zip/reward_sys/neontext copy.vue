<template>
  <div class="neon-wrapper">
    <h1 class="neon-text" :style="neonStyle">{{ text }}</h1>
  </div>
</template>

<script setup>
import { computed } from 'vue'

// Define props with defaults
const props = defineProps({
  text: {
    type: String,
    default: 'NEON GLOW'
  },
  colorA: {
    type: String,
    default: '#ff005e' // Pink glow
  },
  colorB: {
    type: String,
    default: '#00d4ff' // Blue glow
  }
})

// Computed style for dynamic neon colors
const neonStyle = computed(() => ({
  '--neon-color-a': props.colorA,
  '--neon-color-b': props.colorB
}))
</script>

<style scoped>
.neon-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: #000;
  font-family: 'Arial', sans-serif;
  overflow: hidden;
}

.neon-text {
  font-size: 4rem;
  color: #fff;
  text-shadow:
    0 0 5px var(--neon-color-a),
    0 0 10px var(--neon-color-a),
    0 0 20px var(--neon-color-a),
    0 0 40px var(--neon-color-a),
    0 0 80px var(--neon-color-a);
  animation: glow 1.5s infinite alternate;
}

@keyframes glow {
  0% {
    text-shadow:
      0 0 5px var(--neon-color-a),
      0 0 10px var(--neon-color-a),
      0 0 20px var(--neon-color-a),
      0 0 40px var(--neon-color-a),
      0 0 80px var(--neon-color-a);
  }
  100% {
    text-shadow:
      0 0 10px var(--neon-color-b),
      0 0 20px var(--neon-color-b),
      0 0 40px var(--neon-color-b),
      0 0 80px var(--neon-color-b),
      0 0 160px var(--neon-color-b);
  }
}
</style>
