<template> 
  <div class="camera-capture">
    <div v-if="!imageLoaded">
      <div class="section">
        <div class="section-title">Upload Image</div>
        <input type="file" accept="image/*" @change="onFileChange" />
      </div>
      <div class="section">
        <div class="section-title">Camera</div>
        <div class="camera-controls">
          <button class="touch-btn" @click="startCamera">Start Camera</button>
          <video ref="video" autoplay playsinline v-show="showVideo" style="max-width:100%; margin-top: 8px;"></video>
          <button v-if="showVideo" class="touch-btn" @click="captureFromCamera" style="margin-top: 8px;">Capture</button>
        </div>
      </div>
    </div>
    <!-- Always render the canvas, but hide it if not imageLoaded -->
    <div v-if="true">
      <div v-if="imageLoaded" class="section-title">Crop Image</div>
      <canvas
        ref="canvas"
        :width="canvasWidth"
        :height="canvasHeight"
        @mousedown="startCrop"
        @mousemove="moveCrop"
        @mouseup="endCrop"
        :style="imageLoaded ? 'border:1px solid #ccc; max-width:100%; cursor:crosshair; margin-bottom: 12px;' : 'display:none;'"
      ></canvas>
      <div v-if="imageLoaded">
        <div v-if="imageLoaded" class="crop-buttons">
          <button class="touch-btn" @click="cropImage" :disabled="!canCrop">Crop</button>
          <button class="touch-btn" @click="reset">Cancel</button>
        </div>
        <div v-if="croppedDataUrl" class="cropped-preview">
          <button class="save-btn touch-btn" @click="emitCropped">Save</button>
          <img :src="croppedDataUrl" style="max-width:100px; border:1px solid #ccc; margin: 8px 0;" />
          <div class="cropped-actions">
            <button class="touch-btn" @click="reset">Retake</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<script setup>
import { ref, nextTick, computed } from 'vue'
const emit = defineEmits(['captured', 'close'])

const video = ref(null)
const canvas = ref(null)
const showVideo = ref(false)
const imageLoaded = ref(false)
const cropping = ref(false)
const cropStart = ref({ x: 0, y: 0 })
const cropEnd = ref({ x: 0, y: 0 })
const cropRect = ref(null)
const canCrop = computed(() => {
  return cropRect.value && cropRect.value.w > 2 && cropRect.value.h > 2
})
const image = ref(null)
const croppedDataUrl = ref(null)
const canvasWidth = ref(300)
const canvasHeight = ref(300)
let stream = null

function onFileChange(e) {
  const file = e.target.files[0]
  if (!file) return
  const reader = new FileReader()
  reader.onload = (ev) => {
    loadImage(ev.target.result)
  }
  reader.readAsDataURL(file)
}

function startCamera() {
  navigator.mediaDevices.getUserMedia({ video: true }).then(s => {
    stream = s
    showVideo.value = true
    nextTick(() => {
      video.value.srcObject = stream
    })
  })
}

function captureFromCamera() {
  const v = video.value
  const c = canvas.value
  c.width = v.videoWidth
  c.height = v.videoHeight
  const ctx = c.getContext('2d')
  ctx.drawImage(v, 0, 0, c.width, c.height)
  image.value = new window.Image()
  image.value.src = c.toDataURL('image/png')
  image.value.onload = () => {
    imageLoaded.value = true
    showVideo.value = false
    stream.getTracks().forEach(t => t.stop())
    nextTick(() => {
      drawImage()
    })
  }
}

function loadImage(src) {
  image.value = new window.Image()
  image.value.src = src
  image.value.onload = () => {
    imageLoaded.value = true
    canvasWidth.value = image.value.width
    canvasHeight.value = image.value.height
    nextTick(() => {
      drawImage()
    })
  }
}

function drawImage() {
  const c = canvas.value
  const ctx = c.getContext('2d')
  ctx.clearRect(0, 0, c.width, c.height)
  ctx.drawImage(image.value, 0, 0, c.width, c.height)
  if (cropRect.value) {
    ctx.strokeStyle = 'red'
    ctx.lineWidth = 2
    ctx.strokeRect(
      cropRect.value.x,
      cropRect.value.y,
      cropRect.value.w,
      cropRect.value.h
    )
  }
}

function startCrop(e) {
  if (!imageLoaded.value) return
  cropping.value = true
  const rect = canvas.value.getBoundingClientRect()
  const scaleX = canvas.value.width / rect.width
  const scaleY = canvas.value.height / rect.height
  cropStart.value = {
    x: (e.clientX - rect.left) * scaleX,
    y: (e.clientY - rect.top) * scaleY
  }
  cropRect.value = null
}

function moveCrop(e) {
  if (!imageLoaded.value || !cropping.value) return
  const rect = canvas.value.getBoundingClientRect()
  const scaleX = canvas.value.width / rect.width
  const scaleY = canvas.value.height / rect.height
  cropEnd.value = {
    x: (e.clientX - rect.left) * scaleX,
    y: (e.clientY - rect.top) * scaleY
  }
  cropRect.value = {
    x: Math.min(cropStart.value.x, cropEnd.value.x),
    y: Math.min(cropStart.value.y, cropEnd.value.y),
    w: Math.abs(cropEnd.value.x - cropStart.value.x),
    h: Math.abs(cropEnd.value.y - cropStart.value.y)
  }
  drawImage()
}

function endCrop() {
  if (!imageLoaded.value) return
  // Only end cropping if a crop area was actually drawn
  if (cropRect.value && cropRect.value.w > 2 && cropRect.value.h > 2) {
    cropping.value = true
    cropImage()
  } else {
    cropping.value = false
    cropRect.value = null
  }
}

function cropImage() {
  if (!canCrop.value) return
  const c = document.createElement('canvas')
  c.width = cropRect.value.w
  c.height = cropRect.value.h
  const ctx = c.getContext('2d')
  ctx.drawImage(
    image.value,
    cropRect.value.x,
    cropRect.value.y,
    cropRect.value.w,
    cropRect.value.h,
    0, 0, cropRect.value.w, cropRect.value.h
  )
  croppedDataUrl.value = c.toDataURL('image/png')
  // Clear crop rectangle after cropping
  cropRect.value = null
  cropping.value = false
  nextTick(() => drawImage())
}

function emitCropped() {
  // emit cropped image as data url
  emit('captured', { dataUrl: croppedDataUrl.value })
}

function reset() {
  cropRect.value = null
  croppedDataUrl.value = null
  drawImage()
}
</script>
 

<style scoped>
.camera-capture {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.section {
  margin-bottom: 18px;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.section-title {
  font-weight: bold;
  margin-bottom: 8px;
  font-size: 1.1em;
}
.camera-controls {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
}
.crop-buttons {
  margin-bottom: 12px;
  display: flex;
  gap: 10px;
  justify-content: center;
}
.cropped-preview {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.cropped-actions {
  display: flex;
  gap: 10px;
  margin-top: 6px;
}
.save-btn {
  font-size: 1.1em;
  font-weight: bold;
  background: #1976d2;
  color: #fff;
  border: none;
  border-radius: 4px;
  padding: 8px 18px;
  margin-bottom: 4px;
  cursor: pointer;
}
 .save-btn:hover {
  background: #1565c0;
}
.touch-btn {
  font-size: 1.2em;
  padding: 16px 28px;
  min-width: 120px;
  min-height: 48px;
  border-radius: 8px;
  margin: 6px 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  touch-action: manipulation;
}
.touch-btn:active {
  background: #145ea8;
}
.video, .preview, .cropper-img {
  width: 300px;
  height: 300px;
  object-fit: cover;
  border-radius: 8px;
  border: 2px solid #ccc;
}
</style>
